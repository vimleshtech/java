import java.util.ArrayList;
import java.util.Scanner;

public class runtimeDataInArrayList {

	public static void main(String[] args) {
		
		ArrayList al = new ArrayList();
		Scanner sc = new Scanner(System.in);
		
		for(int i=0; i<5;i++)
		{
			System.out.println("enter data : ");
			al.add(sc.nextLine());
			
		}

		for(int i=0; i<al.size();i++)
		{
			System.out.println(al.get(i));
		}

		
	}

}
