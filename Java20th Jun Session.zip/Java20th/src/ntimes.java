import java.util.ArrayList;
import java.util.Scanner;

public class ntimes {

	public static void main(String[] args) {

		ArrayList al = new ArrayList();
		Scanner sc = new Scanner(System.in);
		
		while(true)		
		{
			int op;
			System.out.println("enter 1. for add 2. for show and 3. for exit");
			op=sc.nextInt();
			
			if(op==1)
			{				
				System.out.println("enter data to add in list :");				
				al.add(sc.next());
				
			}
			else if(op==2)
			{
				for(int i=0; i<al.size();i++)
				{
					System.out.println(al.get(i));
				}
			}
			else if (op==3)
			{
				System.out.println("thank you...");
				break;
			}
			else
			{
				System.out.println("invalid choice");
			}
		}

	}

}

	