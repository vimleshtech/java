import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.Scanner;

class emps
{

	String name;
	int sal;
	emps(String n, int s)
	{
			sal =s;
			name =n;
	}
}


public class HashMapDict {

	public static void main(String[] args) {
	
		HashMap map =new HashMap();
		
		map.put("a", "alpha");
		map.put("c", "ceta");
		map.put("t", "tata");
		
		System.out.println(map.get("c"));
		

		////
		HashMap<Integer, emps>  ee=new HashMap<>();
		Scanner sc = new Scanner(System.in);

		System.out.println("enter key id, name salary");
		ee.put(sc.nextInt(), new emps(sc.next(),sc.nextInt()));
		
		System.out.println(ee.get(101).name);
		
		
	}

}
