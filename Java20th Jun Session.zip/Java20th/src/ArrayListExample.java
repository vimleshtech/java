
import java.net.SocketTimeoutException;
import java.util.ArrayList;

public class ArrayListExample {

	public static void main(String[] args) {
		
		//Collection : dynamic type and dynamci size 
		//here ArrayList is inbuilt class, and add is inbuilt function
		ArrayList al = new ArrayList();

		al.add(11);    // 0
		al.add(33444);  //1
		al.add(true);  //2
		al.add("nitin");  //3
		al.add(110); //4 
		al.add(11.3333);
		
		//print 2nd element 
		System.out.println(al.get(1)); 

		//print all elements 
		for(int i=0; i<al.size();i++)
		{
			System.out.println(al.get(i));
		}
	}

}
