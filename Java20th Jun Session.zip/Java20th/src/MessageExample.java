import java.util.Scanner;

public class MessageExample {

	public static void main(String[] args) {
		
		System.out.println("hi");
		int n=1;
		System.out.println(n);
		System.out.println("hi "+n);
		

		Scanner sc = new Scanner(System.in);
		System.out.println("enter data : ");
		String name = sc.nextLine();
		
		String word[]= name.split(" ");
		
		for(int i=0; i<word.length;i++)
		{
		
		String s = word[i].substring(0, 1).toUpperCase();
		s = s+ word[i].substring(1, word[i].length()).toLowerCase();
		
		System.out.print(s+" ");
		
		
			
		}
		

	}

}
