import java.util.ArrayList;
import java.util.Scanner;

class emp
{
	int eid;
	String name;
	emp(int id, String n)
	{
			eid=id;
			name =n;
	}
}

public class ArrayListWithTemplate {

	public static void main(String[] args) {

		ArrayList<Integer> al = new ArrayList();
		al.add(1);
		//al.add("as");

		ArrayList<emp> e= new ArrayList<>();
		Scanner sc = new Scanner(System.in);
		
		for(int i=0; i<5; i++)
		{
		System.out.println("enter id, and name : ");
		e.add(new emp(sc.nextInt(),sc.next()));
		}
		
		/*
		e.add(new emp(1,"nitin"));
		e.add(new emp(11,"ayush"));
		e.add(new emp(2,"divya"));
		e.add(new emp(3,"chahat"));
		e.add(new emp(4,"jatin"));
		*/
		
		for(int i=0; i<e.size();i++)
		{
			System.out.print(e.get(i).eid+"\t");
			System.out.println(e.get(i).name);
		}
		
		
		
		
		
		
		
		

	}

}
