package calc;

public class startup // class 
{

	int out;  //global variable, instance  
	static int data;
	
	//void sum() //function 
	//{
		//local variable : can be access within same function 
		//int a,b,c;
		//a =11;
	//	b =22;
		//c =a+b;
		
		//out =c;
	//}
	public static void main(String[] args)
	{
		//input / raw 
		int a,b,c,d ;  //declaration of variable
		int a3,b3,c3,d3;
		a=3;
		b=4;
		c=5;
		d=6;
		//expression / logic 
		a3 =a*a*a;
		b3 =b*b*b;
		c3 =c*c*c;
		d3=d*d*d;
		if (a3+b3+c3 == d3)
			System.out.println("satisfy");
		else 		
						
	
		System.out.println("not satisfy ");
		
		
		// access to instance variable
		
		
		//we can access without object
		
		
	}

	
}
