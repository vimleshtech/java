package calc;

import java.util.Scanner;

import javax.sound.midi.Soundbank;

public class inputOutput {

	public static void main(String[] args) {
	

		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter data : ");
		int a = sc.nextInt();
		
		System.out.println("output is = "+a);
	}

}
