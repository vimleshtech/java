package DBAction;

public class productManager {

}
