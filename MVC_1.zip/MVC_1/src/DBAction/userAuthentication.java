package DBAction;

public class userAuthentication {
	
	public void login(String email,String pwd)
	{
		
	}

	public void register(String name, String email, String pwd)
	{
		
	}
}
