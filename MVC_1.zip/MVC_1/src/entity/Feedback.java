package entity;

public class Feedback {

 private int fid;
 private int cusid;
 private String comments;
public int getFid() {
	return fid;
}
public void setFid(int fid) {
	this.fid = fid;
}
public int getCusid() {
	return cusid;
}
public void setCusid(int cusid) {
	this.cusid = cusid;
}
public String getComments() {
	return comments;
}
public void setComments(String comments) {
	this.comments = comments;
}
 
}

