package entity;

public class Country {
	
	private int counid;
	private String counname;
	public int getCounid() {
		return counid;
	}
	public void setCounid(int counid) {
		this.counid = counid;
	}
	public String getCounname() {
		return counname;
	}
	public void setCounname(String counname) {
		this.counname = counname;
	}
	
	

}
