import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class CollectionEx {

	public static void main(String[] args) {

		//dynamic size and dynamic type		
		ArrayList al  =new ArrayList(); //ArrayList is class
		al.add(11);
		al.add("nitin");
		al.add(true);

		System.out.println(al.size());				
		al.remove(1);
		System.out.println(al.size());
		
		System.out.println(al.get(0)); //access by index		
		for(int i=0; i<al.size();i++)
		{
			System.out.println(al.get(i));
		}
				
		//List : is interface
		List l = new ArrayList();

		for(int i=0; i<10;i++)
		{
			l.add(100);
		}
		
		for(int i=0; i<l.size();i++)
			System.out.println(l.get(i));
		
		
		//prototype
		ArrayList<Integer> ia =new ArrayList<>(); //can store only inteter
		ia.add(11);
		//ia.add("11");
		ia.add(1133);
		System.out.println(ia.get(1));
		
		
		//Dictinary 
		HashMap map = new HashMap();
		map.put("a", "apple");
		map.put("d", "data");
		map.put("b", "beta");
		map.put("c", "cetta");
		
		Scanner sc =new Scanner(System.in);
		String k;
		System.out.println("enter key to search :");
		k = sc.nextLine();
		
		
		System.out.println(map.get(k));
		
	}
}
