package threadEx;

public class processEx {

	public static void main(String[] args) throws InterruptedException {

		
		Thread o = Thread.currentThread();
		System.out.println(o);
		System.out.println(o.getName());
		System.out.println(o.getPriority());
		
		newThread t =new newThread("New Process");
		
		for(int i=0;i<5;i++)
		{
			System.out.println("main function:"+i);
			Thread.sleep(500);
			
		}

	}

}

class newThread implements Runnable
{
	Thread th=null;
	newThread(String name)
	{
		th=new Thread(this,name);
		th.start();
	}
	
	public void run()
	{
		try
		{
			for(int i=0;i<5;i++)
			{
				System.out.println("thread class :"+i);
				Thread.sleep(500);
				
				
			}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
}
