import java.util.ArrayList;

class emp{
	
	int id;
	String name;
	int sal;
	
	emp(int id, String name,int sal)
	{
		this.id =id;
		this.name =name;
		this.sal  =sal;
	}
	
}
public class Employee {

	public static void main(String[] args) {
		

		ArrayList<emp> e =new ArrayList<>();
		e.add(new emp(1,"nitin",1012223));
		e.add(new emp(2,"raman",2112223));
		e.add(new emp(3,"chahat",8112223));
		e.add(new emp(4,"monika",1012223));
		e.add(new emp(5,"jatin",1012223));
		
		for(int i=0;i<e.size();i++)
		{
			System.out.println(e.get(i).id+"\t"+e.get(i).name+"\t"+e.get(i).sal);
		}
	}

}
