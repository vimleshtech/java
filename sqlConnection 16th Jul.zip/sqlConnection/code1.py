a = 111 # here a is varibale
b =333 # here b is varibale

c = a+b # expression

print(c) #show result 

