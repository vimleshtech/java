package connectionExample;

//to establish the connection 
import java.sql.Connection;
//to register the driver (mysql,oralce)
import java.sql.DriverManager;
//run sql command 
import java.sql.PreparedStatement;
//exception hnadler 
import java.sql.SQLException;
import java.util.Scanner;
//hold/contains result 
import java.sql.ResultSet;



public class conExample {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
			
			Scanner sc = new Scanner(System.in);
			String n,e;
			System.out.println("enter name : ");
			n = sc.nextLine();
			
			System.out.println("enter email: ");
			e = sc.nextLine();
			
			//register or load my sql driver 
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hrms", "root", "root");
			
			PreparedStatement ps = con.prepareStatement("insert into emp(name,email) values(?,?)") ;
			
			ps.setString(1, n);
			ps.setString(2, e);
			ps.executeUpdate();
			
			
			//read data 
			ps = con.prepareStatement("select * from emp;");
			ResultSet rs  = ps.executeQuery();
			
			while(rs.next())
			{
				System.out.println(rs.getString(1)+rs.getString(2));
			}
			con.close();
			System.out.println("data is saved..");
			
			
			
	}

}
