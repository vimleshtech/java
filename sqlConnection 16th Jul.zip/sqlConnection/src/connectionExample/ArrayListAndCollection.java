package connectionExample;

import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

class emp{
	
	int id;
	String name;
	emp(int id,String name)
	{
		this.id  =id;
		this.name = name;
	}
	
}
public class ArrayListAndCollection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//we can store any type of data 
		//dynamic size
		ArrayList al = new ArrayList();
		
		al.add(11);
		al.add("raman");
		al.add(333.4);
		al.add(true);
		
		
		System.out.println(al.size());
		System.out.println(al.get(0));
		
		al.remove(1); //remove name
		System.out.println(al.size());
		
		
		for(int i=0; i<al.size();i++)
		{
			System.out.println(al.get(i));
		}
		
		//list  
		//dynamic size but fix type : string 
		List<String> s = new ArrayList<String>();
		//s.add(11);
		s.add("sjhss");
		s.add("sjhss");
		s.add("sjhss");
		s.add("sjhss");
		

		System.out.println(s.size());
		System.out.println(s.get(0));
		
		s.remove(1); //remove name
		System.out.println(s.size());
		
		
		////
		ArrayList<emp> e =new ArrayList<emp>();
		
		e.add(new emp(11,"jatin"));
		e.add(new emp(12,"jatin"));
		e.add(new emp(13,"jatin"));
		e.add(new emp(14,"jatin"));
		e.add(new emp(15,"jatin"));
		
		
		for(int i=0; i<e.size();i++)
		{
			System.out.println(e.get(i).id+"\t"+e.get(i).name);
		}
	
		
		//
		HashMap map = new HashMap();
		map.put(1, "nitin");
		map.put(11, "jatin");
		map.put(12, "raman");
		map.put(13, "ayush");
		map.put(14, "chahat");
		
		System.out.println(map.get(11));
		
		
		
		
	}

}
