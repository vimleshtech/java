package abstractEx;

public abstract class prototype {

	int a;
	
	void add(int a, int b)
	{
		this.a =a;
		
		System.out.println(a+b);
	}
	
	//declaration of methods 
	abstract void mul(int a, int b);
	abstract void div(int a, int b);
	
}
