package abstractEx;

public class imps  extends prototype{

	@Override
	void mul(int a, int b) {
		System.out.println(a*b);
		
	}

	@Override
	void div(int a, int b) {
		System.out.println(a/b);
		
	}

}
