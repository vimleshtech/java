package abstractEx;

public class caller {

	public static void main(String[] args) {
	
		imps o =new imps();
		o.add(11, 2);
		o.div(211,2);
		

	}

}
