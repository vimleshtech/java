package oops;

import javax.xml.soap.SOAPException;

public class caller {

	public static void main(String[] args) {

		//parent class function, member can be access from child class object
		//single level
		compute c =new compute();
		c.add(11, 22);
		c.tax(333333);
		c.sub(333, 33);
		
		//mult level 
		digitalCalc dg =new digitalCalc();
		dg.add(11, 22);
		dg.sub(333, 33);
		dg.tax(43333);
		dg.saleTax(333, 200);
		
		//tree : calc 
		scoreCard sc =new scoreCard();
		sc.add(11, 22);
		sc.printGrade(55, 77, 88);
		
		
		compute co =new compute(); //: calc  
		co.add(11, 43343);
		co.tax(34333);
		
		
		
	}

}
