package oops;

//tree
public class scoreCard extends calc {

	void printGrade(int hs,int cs, int es)
	{
		int total =hs+es+cs;
		System.out.println(total);
		int avg = total/3;
		System.out.println(avg);
		if(avg>=80)
		{
			System.out.println("A"); 
		}
		else if(avg>=60)
		{
			System.out.println("B");
		}
		else
		{
			System.out.println("C");
		}
	}
}
