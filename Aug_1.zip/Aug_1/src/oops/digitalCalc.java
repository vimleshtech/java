package oops;

public class digitalCalc extends compute {

	void saleTax(int qty,int price)
	{
		int total = qty*price;
		double tax=0;
		if(total>1000)
		{
			tax = total*.18;
			System.out.println(tax);
		}
		else
		{
			tax = total*.12;
			System.out.println(tax);
		}
	}
}
