package oops;

//here compute is child/derived class, and calc is parent /super class
public class compute extends calc {

	void tax(int sal)
	{
		if(sal<300000)
		{
			System.out.println("no tax");
		}
		else
		{
			System.out.println("taxable income..");
		}
	}
}
