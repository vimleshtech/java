package interfaceEx;

public interface ib {

	void mul(int a, int b);
	
}
