package interfaceEx;

public interface ia {

	void add(int a, int b);
	int sub(int a, int b);
	
}
