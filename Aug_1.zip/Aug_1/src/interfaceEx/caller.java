package interfaceEx;

public class caller {

	public static void main(String[] args) {
	
		imps i =new imps();
		i.add(11, 22);
		i.sub(22, 23);
		i.mul(22, 33);
		
		ia a =new imps();
		a.add(11, 22);
		a.sub(233, 3);
	
	
		ib b =new imps();
		b.mul(11, 22);
		
	

	}

}
