package interfaceEx;

public class imps implements ia,ib {

	@Override
	public void mul(int a, int b) {
		// TODO Auto-generated method stub

		System.out.println(a*b);
	}

	@Override
	public void add(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a+b);
		
	}

	@Override
	public int sub(int a, int b) {
		// TODO Auto-generated method stub
		return a-b;
	}

}
