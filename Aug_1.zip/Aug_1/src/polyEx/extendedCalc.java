package polyEx;

public class extendedCalc extends calc {

	int d1;
	
	void welcome()
	{
		System.out.println("this is child  class");
	}
	
	void add(double d1, double d2)
	{
		d1 =1; //local within function
		this.d1 =222;// current class or parent class
		super.d1 =3333; //parent class 
		
		System.out.println(super.d1+d2);

	}
	void mul(int a, int b)
	{
		System.out.println(a*b);
	}
	void mul(int a, int b,int c)
	{
		System.out.println(a*b*c);
	}
	
}
