package polyEx;

public class calc {

	int d1;
	
	void welcome()
	{
		System.out.println("this is parent class");
	}
	void add(int a, int b)
	{
		System.out.println(a+b);
	}
	void add(int a, int b, int c)
	{
		System.out.println(a+b+c);
	}
	
	void sub(int x,int y)
	{
		System.out.println(x-y);
	}
}
