package polyEx;

public class caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		extendedCalc c =new extendedCalc();
		c.add(11.33, 333.22);
		c.add(11, 23,33);
		c.add(11, 23);
		c.mul(11, 23,33);
		c.mul(11, 23);
		
		 
		calc p =new calc();
		p.welcome();
		
		extendedCalc ch =new extendedCalc();
		ch.welcome();
		
		//override
		p =ch;
		p.welcome();//child class function
		//or
		calc oo = new extendedCalc();
		oo.welcome();//child 
		
	}

}
