package questions;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class throwsExz {

	public static void main(String[] args) throws FileNotFoundException {

		FileReader fr  =new FileReader("c://abc//a.txt");
		

	}

}
