package questions;

public class q763 {

	public static void main(String[] s)
	{
		
		for(int i=1; i<40; i=i+3)
		{
			if(i%2==0)
			{
				System.out.print("-"+i+",");
			}
			else
			{
				System.out.print(i+",");
			}
		}
		
		
		////
		int arr[] = {111,2,223,3,3,3344};
		int sum=0;
		for(int d:arr)
		{
			sum+=d;
		}
		System.out.println(sum);
		
		
		/// 3*3 
		int arr1[][] = {{1,2,3},{3,4,5},{5,6,7}};
		sum =0;
		
		for(int row[] : arr1) //read row by row 
		{
			for(int col:row)
			{
					sum +=col;
			}
		}
		
		System.out.println(sum);
		
		
	}
}
