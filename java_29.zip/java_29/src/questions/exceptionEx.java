package questions;

import java.util.Scanner;

public class exceptionEx {

	public static void main(String[] args) {

		
		int n,d,o;
		Scanner sc =new Scanner(System.in);
		
		System.out.println("enter data ");
		n = sc.nextInt();
		
		System.out.println("enter divisor ");
		d = sc.nextInt();
		
		try
		{
			//div
			o = n/d;
			System.out.println(o);
		}
		catch (ArithmeticException e) {
			System.out.println(e);
		}
		catch (ArrayIndexOutOfBoundsException e) {
				System.out.println(e);
		}
		catch (Exception a) //here Exception is inbuilt class which can capture any types of error 
		{
			System.out.println("technical error ");
		}
		finally {
			System.out.println("end of div block");
		}
		try
		{
				//sum
				o= n+d;
				System.out.println(o);
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}

}
