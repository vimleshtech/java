package questions;

import java.util.Scanner;


public class stringEx {

	public static void main(String[] args) {

		Scanner sc =new Scanner(System.in);
		String data,ns;
		
		System.out.println("enter sentence : ");
		data = sc.nextLine();
		
		ns = data.toUpperCase();
		System.out.println(ns);
		
		ns = data.toLowerCase();
		System.out.println(ns);
		
		ns = data.replace("a", "bc");
		System.out.println(ns);
		
		int l;
		l = data.length();
		System.out.println(l);
		
		int ps;
		ps = data.indexOf("is");
		System.out.println(ps);
		
		ns=data.substring(3, 6); //3,4,5 
		System.out.println(ns);
		

		char c;
		c = data.charAt(1);
		System.out.println(c);
		//convert to ascci
		int d= c;
		System.out.println(d);
		
		ns=data.trim();
		l = ns.length();
		System.out.println(l);
		
		
		///split 
		String w[] = data.split(" ");//raman kumar sinha = ["raman","kuamr","sinha"]
		System.out.println(w[0]); //access 1st name by index 
		
		for(String cw:w)
		{
			System.out.println(cw);
		}
		
		//concat 
		ns = data.concat(" new string");
		//or 
		ns = data+" new string";
		
		
		//conditional function 
		if(data.equals("raman sinha")) //exact compare :case sensetive
		{
			System.out.println("raman sinha - match");
		}
		else
		{
			System.out.println("raman sinha - didn't match");
		}
		
		//
		if(data.equalsIgnoreCase("raman sinha")) //case in-sensetive
		{
			System.out.println("match - in-sensetive");
		}
		else
		{
			System.out.println("not match - in-sensetive");
		}
		//
		if(data.contains("is")) //anywhere 
		{
			System.out.println("is contains");
		}
		else
		{
			System.out.println("is not contain");
		}
		
		//
		if(data.startsWith("r"))
		{
			System.out.println("start with r ");
		}
		else
		{
			System.out.println("not start with r ");
		}
		
		//
		if(data.endsWith("n"))
		{
			System.out.println("end with n ");
		}
		else
		{
			System.out.println("not end with n");
		}
	}

}
