package questions;

import java.util.Scanner;

public class functionEx {

	
	
	public static void main(String[] args) 
	{
		welcome();

		System.out.println(getName()+" "+getName());
		//or
		String o=getName();
		
		
		addNum(11, 333);
		addNum(4444, 44);
		
		
		int oo;
		oo =subNum(1111, 33);
		System.out.println(oo);
		
		addNum(oo,444);
		
		
		
	}

	//no argument no return
	static void welcome()
	{
		System.out.println("welcome to function world!!!");
	}
	//no argument with return
	static String getName()
	{
		Scanner sc =new Scanner(System.in);
		String name;
		System.out.println("enter name :");
		name = sc.nextLine();
		
		return name;
		
	}
	
	//argument with no return
	static void addNum(int a, int b)
	{
		int c=a+b;
		System.out.println("sum of two numbers :"+c);
	}
	
	//argument with return
	static int subNum(int n, int m)
	{
		int d =n-m;
		return d;
	}
}
