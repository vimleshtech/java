package oops;

public class Sales {

}
