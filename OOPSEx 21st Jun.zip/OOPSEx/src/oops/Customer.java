package oops;

public class Customer {

}
