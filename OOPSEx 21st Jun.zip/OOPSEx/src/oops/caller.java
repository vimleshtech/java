package oops;

public class caller {

	public static void main(String[] args) {
		
		//create object of class product
		Product p1 = new Product(); //new is keyword which allocates memory
		p1.show();
		
		Product p2 = new Product("Dove"); //new is keyword which allocates memory
		p2.show();
		
		Product p3 = new Product(11,"sony phone",44000); //new is keyword which allocates memory
		p3.show();
		
		Product p4 = new Product(p3); //new is keyword which allocates memory
		p4.show();
		
		p1.newProduct();
		p2.newProduct();
		p3.newProduct();
		p4.newProduct();
		
		
		p3.show();
		p1.show();
		p4.show();
		p2.show();
		

	}

}
