package oops;

import java.util.Scanner;

public class Product {

	//data members 
	int pid;
	String pname;
	double price;
	
	//default/without parameter
	Product()
	{
		System.out.println("object is created");
	}
	//with argument/parameter
	Product(String name)
	{
		pname= name;
		System.out.println("object is created");
	}
	Product(int id, String name, int p)
	{
		pname= name;
		pid  =id;
		price = p;
		System.out.println("object is created");
	}
	
	//copy constructor
	Product(Product pp)
	{
		pname= pp.pname;
		pid  =pp.pid;
		price = pp.price*1.18;
		
		System.out.println("object is created");
	}
	
	//methods/functions
	public void newProduct()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter pid :");
		pid = sc.nextInt();

		System.out.println("enter product name :");
		pname= sc.next();

		
		System.out.println("enter price :");
		price= sc.nextInt();

	}
	public void show()
	{
		System.out.print("product id is "+pid);
		System.out.print("\t product name is "+pname);
		System.out.println("\t product price "+price);
		
	}
	
}
