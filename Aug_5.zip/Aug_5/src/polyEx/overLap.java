package polyEx;

public class overLap extends calc {

	//overlap
	void welcome()
	{
		System.out.println("welcome to child class - overLap");
	}
	//overlap
	void add(int a, int b)
	{
		System.out.println("sum of two numbers : "+(a+b));
	}
	void mul(int a, int b)
	{
		System.out.println(a*b);
	}
}
