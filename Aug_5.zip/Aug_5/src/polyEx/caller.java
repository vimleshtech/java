package polyEx;

public class caller {

	public static void main(String[] a)
	{
		calc c =new calc();
		c.add(11.22, 333.4);
		c.add(11, 333);
		c.add(1,22,3);
		
		//
		calc co =new calc();
		co.add(11.3, 22.3); //
		co.welcome(); //parennt 
		
		///
		overLap oo =new overLap();
		oo.add(11.3, 22.3);//
		oo.welcome();//d
		
		//overriding
		co =oo;
		co.welcome();//child 
	
		//overriding
		calc cc = new overLap();
		cc.welcome(); //child 
		
	}
}
