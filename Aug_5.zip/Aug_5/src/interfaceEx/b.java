package interfaceEx;

public interface b {

	void div(int a, int b);
	
}
