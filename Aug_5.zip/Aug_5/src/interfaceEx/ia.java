package interfaceEx;

public interface ia 
{
	void add(int a, int b);
	void sub(int a, int b);
	int mul(int a, int b);
}
