package interfaceEx;

import java.net.SocketTimeoutException;

public class imps implements ia,b {

	@Override
	public void div(int a, int b) {
		// TODO Auto-generated method stub
		
		System.out.println(a/b);
	}

	@Override
	public void add(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a+b);
	}

	@Override
	public void sub(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a-b);
	}

	@Override
	public int mul(int a, int b) {
		// TODO Auto-generated method stub
		return a*b;
	}

}
