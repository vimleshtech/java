package interfaceEx;

public class caller {

	public static void main(String[] aa)
	{
		imps c =new imps();
		c.add(11, 22);
		c.mul(11, 22);
		
		
	}
}
