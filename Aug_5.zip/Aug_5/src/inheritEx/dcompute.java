package inheritEx;


//here dcompute is child class, and compute is super/parent class
public class dcompute extends compute {

	void mul(int a, int b)
	{
		System.out.println(a*b);
	}
	void tax(int sal )
	{
		int ysal =sal*12;
		if(ysal<300000)
		{
			System.out.println("not tax");
		}
		else
		{
			System.out.println("taxable income");
		}
	}
}
