package inheritEx;

//tree
public class saleTax extends compute {

	void testSal()
	{
		System.out.println("test.... sale tax");
	}
}
