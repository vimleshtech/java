package inheritEx;

//multi level 
public class incometax extends dcompute {

	void cal(int s)
	{
		System.out.println("yearly sal is "+(s*12));
		
	}
}
