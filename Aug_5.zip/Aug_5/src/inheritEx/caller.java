package inheritEx;

public class caller {

	public static void main(String[] args) {
		
		//parent calss function can be access from child class object
		dcompute d =new dcompute();
		d.add(11, 22);
		d.add(100, 200);
		d.mul(100, 200);
		d.tax(1233433);
		
		
		//object of child : multi level
		incometax i =new incometax();
		i.cal(333343);
		i.tax(33333);
		i.sub(333, 33);
		
		/// tree
		saleTax st =new saleTax();
		st.testSal();
		st.add(11, 22);
		
		
		
		

	}

}
