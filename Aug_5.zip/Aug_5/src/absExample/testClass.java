package absExample;

public abstract class testClass {

	abstract void add(int a, int b);
	abstract int div(int a, int b);
	
	void sub(int a, int b)
	{
		System.out.println(a-b);
	}
}
