package absExample;

public class caller {

	public static void main(String[] a)
	{
		
		testClass t =new imps();
		t.add(11, 22);
		t.sub(333, 3);
		
		
	}
}
