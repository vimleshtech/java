package absExample;

public class imps extends testClass {

	@Override  //annoation 
	void add(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a+b);
		
	}

	@Override
	int div(int a, int b) {
		// TODO Auto-generated method stub
		return a/b;
	}

}
