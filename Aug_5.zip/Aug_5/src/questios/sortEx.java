package questios;

public class sortEx {

	public static void main(String[] args) {

		int n[] = {1,2,2222,43323,2221,212,34,4};
		//n[0] = n[1]
		for(int i=0; i<n.length;i++)
		{			
			for(int j=i+1;j<n.length;j++)
			{
				if(n[i]>n[j])
				{
					int t;
					t =n[i];
					n[i] =n[j];
					n[j] =t;
				}
			}
		}

		for(int x:n)
			System.out.println(x);
	}

}
