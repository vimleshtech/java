package utilities;

import java.io.FileInputStream;
import java.util.Properties;

public class objectReader {

	public static Properties readObjects()
	{		
		Properties prop=null;
		try
		{
				FileInputStream fs = new FileInputStream("C:\\Users\\vkumar15\\eclipse\\HybridProject\\src\\objectsRepository\\Object.properties");
			prop = new Properties();
			prop.load(fs);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return prop;
		
	}
	
}
