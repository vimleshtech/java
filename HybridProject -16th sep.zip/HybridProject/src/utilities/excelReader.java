package utilities;

import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class excelReader {

	public static String[][] readExcel(String tid) {
		
		String data [][]= null; 
		try
		{			
			FileInputStream fs = new FileInputStream("C:\\Users\\vkumar15\\Desktop\\Weekend\\14th Sep\\testcase.xls");
			HSSFWorkbook book = new HSSFWorkbook(fs);
			HSSFSheet sheet = book.getSheetAt(1);
			
			int rc = sheet.getPhysicalNumberOfRows();
			data = new String[rc][4];
			int aindex =0;
			
			for(int i=1; i<rc;i++)
			{
				HSSFRow row = sheet.getRow(i);
				HSSFCell cell = row.getCell(0);
				if(cell.getStringCellValue().equals(tid))
				{
					data[aindex][0]= cell.getStringCellValue();
					
					cell = row.getCell(1);
					data[aindex][1]= cell.getStringCellValue();
					
					cell = row.getCell(2);
					data[aindex][2]= cell.getStringCellValue();
					
					cell = row.getCell(3);
					data[aindex][3]= cell.getStringCellValue();
					
					aindex++;
					
				}
				
			}
			
			
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return data;		

	}

}
