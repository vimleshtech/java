package webActivity;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class webAction {

	
	public static WebElement getElement(WebDriver d, String by, String value)
	{
		WebElement el=null;
		by = by.toUpperCase();
		
		switch (by) 
		{
					case "ID":
						el = d.findElement(By.id(value));
						break;
					case "NAME":
						el = d.findElement(By.name(value));
						break;
					case "XPATH":
						el = d.findElement(By.xpath(value));
						break;			
			
					default:
							break;
		}
		return el;		
				
	}	

	public static void performAction(WebElement el, String by, String value)
	{
		by=by.toUpperCase();
		
		switch (by) 
		{
			case "CLICK":
				el.click();			
				break;
			case "SENDKEYS":
				el.sendKeys(value);
			default:
				break;
		}
		
	}
	
}
