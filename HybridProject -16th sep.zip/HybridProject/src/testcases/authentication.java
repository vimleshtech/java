package testcases;

import org.testng.annotations.Test;

import utilities.excelReader;
import utilities.objectReader;
import webActivity.webAction;

import org.testng.annotations.DataProvider;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;

public class authentication {
	
	static WebDriver driver = null;
	
  @Test
  public void test_ERP_01() 
  {
	 String data[][] = excelReader.readExcel("ERP_01");
	 
	  //driver.findElement(By.id(""));
	 WebElement el= webAction.getElement(driver, data[0][2], objectReader.readObjects().getProperty("uid"));
	 webAction.performAction(el, data[0][3], data[0][4]);
	 
	 
	 el= webAction.getElement(driver, data[1][2], objectReader.readObjects().getProperty("upwd"));
	 webAction.performAction(el, data[1][3], data[1][4]);
	 
	 el= webAction.getElement(driver, data[2][2], objectReader.readObjects().getProperty("btn"));
	 webAction.performAction(el, data[2][3], "");
	 
	 
	  
  }

  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { 1, "a" },
      new Object[] { 2, "b" },
    };
  }
  @BeforeTest
  public void beforeTest() {
	  
	  //driver = new ChromeDriver();
	  System.out.println(objectReader.readObjects().getProperty("url"));
	  //driver.get(objectReader.readObjects().getProperty("url"));
	  
  }

}

