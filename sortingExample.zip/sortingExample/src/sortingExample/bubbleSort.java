package sortingExample;

import java.util.Scanner;

public class bubbleSort {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int size;
		System.out.println("etner size of array :");
		size = sc.nextInt();
		
		int arr[] = new int[size];
		
		//input
		for(int i=0; i<size;i++)
		{
			System.out.println("enter data : ");
			arr[i] = sc.nextInt();
		}

		//sorting -bubble
		for(int i=0; i<size;i++)
		{
			for(int j=i+1; j<size;j++)
			{
				if(arr[i]>arr[j])
				{
						int t;
						t = arr[i];
						arr[i] = arr[j];
						arr[j]= t;
				}
			}
		}
		
		
		//print
		for(int i=0; i<size;i++)
		{
			System.out.println(arr[i]);
		}
	}

}
