package sortingExample;

import java.util.Scanner;


public class insertionExample {

	static int arr[]; //here 5 is size of array
	static int n,i=0;
	
	public static void sortData(int data)
	{
		if(i==0)
		{
			arr[i]=data;
			i++;
		}
		else 
		{
			//System.out.println("test");
			for(int ind=--i; ind>=0;ind--)
			{
				//System.out.println(ind);
				if(arr[ind]>data)
				{
					int t = arr[ind];
					arr[ind]=data;
					arr[ind+1]=t;
				}
				else 
				{
					arr[i]=data;
					i++;
				}
			}
		}
	}
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);		
		int size=0;
		System.out.println("enter size of array :");
		size= sc.nextInt();
		arr=new int[size];
		
		
		while(true)
		{
				int op;
				System.out.println("1. for add 2. for show 3. for exit");
				op=sc.nextInt();
				
				if(op==1)
				{
					if(i<size)
					{
						System.out.println("enter data : ");
						n = sc.nextInt();
						sortData(n);
						
						i++;
					}
					else
					{
						System.out.println("array is full");
					}
					
					
				}
				else if(op==2)
				{
					if(i==0)
					{
						System.out.println("array is empty");
					}
					else
					{
						for(int d: arr)
						{
							System.out.println(d);
						}
					}
				}
				else if(op==3)
				{
					System.exit(0);
				}
				else
				{
					System.out.println("invalid choice");
				}
				
		}
		
		

	}

}
