package testcases;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class yahooTest {


	@Test
	public void test()
	{
		System.out.println("calls yahoo. - test");
		
		WebDriver driver =new ChromeDriver();
		driver.get("https://www.yahoo.com/");
		
		String url= driver.getCurrentUrl();
		
		Assert.assertEquals("https://www.yahoo.com/", url);
		
	}
	
}
