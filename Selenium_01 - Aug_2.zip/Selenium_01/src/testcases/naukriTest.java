package testcases;

import org.junit.Test;

public class naukriTest 
{

	@Test
	public	void test()
	{
		System.out.println("calls nau. - test");
	}
	@Test
	public	void testLogin()
	{
		System.out.println("calls nau. - test login");
	}
	
}
