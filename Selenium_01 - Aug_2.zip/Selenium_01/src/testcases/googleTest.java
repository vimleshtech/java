package testcases;

import static org.junit.Assert.fail;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;

public class googleTest {


	@Test
	public void test()
	{
		System.out.println("calls google. - test");
		
		fail("failed...");
	}
	@Test
	public void testAdd()
	{
	
		int a,b,c;
		a =4;
		b =2;		
		try
		{
			c =a/b;
			System.out.println(c);
		}
		catch (Exception e) 
		{
			fail("arithmetic error");
		}
		
		
	}
	
	@Test
	public void testSub()
	{
		int a,b,c;
		a =4;
		b =4;
		
		c =a-b;
		Assert.assertEquals(1, c);//expected, actual 
		
				
	}
	
	@Ignore
	@Test
	public  void testSearch()
	{
		System.out.println("calls goole. - test search");
	}
	
}

