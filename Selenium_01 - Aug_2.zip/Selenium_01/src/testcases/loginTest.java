package testcases;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Ignore;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class loginTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception 
	{
	
		System.out.println("Before All");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception 
	{
		System.out.println("After All");
	}

	@BeforeEach
	void setUp() throws Exception 
	{
		System.out.println("Before each");
	}

	@AfterEach
	void tearDown() throws Exception 
	{
		System.out.println("After each");
		
	}

	@Test
	void test() 
	{
		System.out.println("test");
	}

	@Ignore
	@Test
	void testLogin()
	{
		System.out.println("test - login"); 
	}
	@Test
	void testSearch()
	{
				
		System.out.println("test - search");
	}
	@Ignore
	@Test
	void testLogout()
	{
		System.out.println("test logout");
	}
}
