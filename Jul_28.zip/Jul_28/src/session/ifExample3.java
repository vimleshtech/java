package session;

import java.util.Scanner;

public class ifExample3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc =new Scanner(System.in);
		int sales,discount=0;
		
		System.out.println("enter sales amount:");
		sales =sc.nextInt();
		
		if(sales>100000)
		{
			discount = 5000;
		}
		else if (sales>50000 ) //&& sales<1000000
		{
			discount = 2000;
		}
		else if(sales>10000)
		{
			discount = 500;
		}
		else if(sales>2000)
		{
			discount = 100;
		}
		else
		{
			discount = 50;
		}
		sales = sales-discount;
		System.out.println("you have to pay INR :"+sales);
		

	}

}
