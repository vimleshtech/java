package session;

import java.util.Scanner;

public class ifExample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc =new Scanner(System.in);
		int sales,discount=0;
		
		System.out.println("enter sales amount:");
		sales =sc.nextInt();
		
		if(sales>1000)
		{
			discount = 100;
		}
		else
		{
			discount = 50;
		}
		sales = sales-discount;
		System.out.println("you have to pay INR :"+sales);
		

	}

}
