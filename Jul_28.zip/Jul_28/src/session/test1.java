package session;

import java.util.Scanner;

public class test1 {

	public static void main(String[] args) {

		
		
		//create object
		Scanner s = new Scanner(System.in);
		//declare variable 
		String name;
		int n;
				
		System.out.println("Enter name : ");
		name = s.nextLine(); //take input 
				

		System.out.println("Enter id  : ");
		n = s.nextInt(); //take input 
				
		//output 
		System.out.println("you have entered : "+name);
		System.out.println("you have entered : "+n);
		
		
		
		

	}

}
