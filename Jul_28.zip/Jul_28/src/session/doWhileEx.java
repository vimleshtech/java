package session;

public class doWhileEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//do while: will execute at least one time
		//first execute then check the condition
		int i=0;
		
		do {
			
			System.out.println(i);
			i++;
		}while(i<0);
	}

}
