package session;

public class arrayEx {

	public static void main(String[] args) {

		int n[] = new int[3];
		n[0] =1;
		n[1] =31;
		n[2] =14;
		
		//access by index
		//System.out.println(n[1]);
		
		//print all 
		for(int i=0; i<3;i++)
		{
			System.out.println(n[i]);
		}
		
		//advance loop
		for(int d : n) 
		{
			System.out.println(d);	
		}

	}

}
