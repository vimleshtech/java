package session;

import java.util.Scanner;

public class ifExample {

	public static void main(String[] args) {
		
		Scanner sc =new Scanner(System.in);
		int sales,discount=0;
		
		System.out.println("enter sales amount:");
		sales =sc.nextInt();
		
		if(sales>1000)
		{
			discount = 100;
		}
		
		sales = sales-discount;
		System.out.println("you have to pay INR :"+sales);
		

	}

}
