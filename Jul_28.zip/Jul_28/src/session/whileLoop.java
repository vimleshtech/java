package session;

public class whileLoop {

	public static void main(String[] args) {
		
		int i=1;  //init 
		while(i<10) //condition 
		{
			
			System.out.print(i);
			i++; //increment // i =i+1
			
		}
		
		//print in reverse 
		i =10;
		while(i>0)
		{
			System.out.println(i);
			i--;
		}
			
		//print all odd numbers between 1 to 30
		i =1;
		while(i<=30)
		{
			System.out.println(i);
			i=i+2;
		}
		
		///wap to get sum of all even and odd numbers between 1 to 100
		int se=0,so=0;
		i=1;
		while(i<=100)
		{
			if(i%2==0)
				se =se+i;
			else
				so  +=i;
			
			i++;
		}
		System.out.println("sum of all even numbers : "+se);
		System.out.println("sum of all odd numbers : "+so);
		
		

	}

}
