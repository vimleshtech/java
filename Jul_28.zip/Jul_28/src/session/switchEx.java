package session;

import java.util.Scanner;

public class switchEx {

	public static void main(String[] args) {

			Scanner sc =new Scanner(System.in);
			int op,a,b,c;
			
			System.out.println("press 1 for add 2 for sub 3 for mul");
			op = sc.nextInt();
			

			System.out.println("enter value for a : ");
			a = sc.nextInt();
			
			System.out.println("enter value for b : ");
			b = sc.nextInt();

			
			
			switch (op) 
			{
				case 1:
					c =a+b;
					System.out.println("sum of two numbers : "+c);
					
					break;
				case 2:
					{	
					c =a-b;
					System.out.println("sub of two numbers : "+c);
					
					break;
					}
				case 3:
					c =a*b;
					System.out.println("mul of two numbers : "+c);
					break;
				default:
					System.out.println("invalid choice");
					break;
			}
			
			
			
			
		
		

	}

}
