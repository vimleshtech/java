package session;

import java.util.Scanner;

import javax.xml.transform.Source;

public class dynamicArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc =new Scanner(System.in);
		int s;
		System.out.println("enter size of array :");
		s = sc.nextInt();
		
		int arr[] =new int[s];
		
		for(int i=0; i<s;i++)
		{
			System.out.println("enter data : ");
			arr[i] =sc.nextInt();
		}
		
		//print
		for(int d:arr)
		{
			System.out.println(d);
		}
		
		
		
		////
		int r,c;
		System.out.println("enter row size :");
		r=sc.nextInt();
		System.out.println("enter col size :");
		c=sc.nextInt();
		
		String data[][] = new String[r][c];
		
		for(int i=0; i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				System.out.println("enter data : ");
				data[i][j] =sc.next();
			}
		}
		//print 
		for(String row[] :data)
		{
			for(String col:row)
			{
				System.out.print(col);
			}
			System.out.println();
		}
	}

}
