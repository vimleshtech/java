package session;

import java.util.Scanner;
import java.util.concurrent.CountDownLatch;

public class ifExample4 {

	public static void main(String[] args) {
	
		Scanner sc =new Scanner(System.in);
		int a,b,c;
		
		System.out.println("enter no. : ");
		a =sc.nextInt();
		
		System.out.println("enter no. : ");
		b =sc.nextInt();
		
		System.out.println("enter no. : ");
		c =sc.nextInt();
		
		//show greater no.
		if(a>b && a>c)
		{
			System.out.println("a is greater");
		}
		else if(b>a && b>c)
		{
			System.out.println("b is greater");
		}
		else
		{
			System.out.println("c is greater ");
		}
		//nested if else 
		if(a>b)
		{
				if(a>c)
					System.out.println("a is gt");
				else
					System.out.println("c is gt");
		
		}
		else
		{	
				if(b>c)
					System.out.println("b is gt");
				else
					System.out.println("c is gt");
		}

	}

}
