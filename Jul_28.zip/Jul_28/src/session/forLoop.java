package session;

import java.util.Scanner;

public class forLoop {

	public static void main(String[] args) {

		int se=0,so=0;
		for(int i=1;i<=100;i++)
		{
			if(i%2==0)
				se +=i;
			else
				so+=i;
			
		}
		System.out.println(se);
		System.out.println(so);

		
		//wap to print table of given no.
		int t;
		Scanner sc =new Scanner(System.in);
		System.out.println("enter nub. to print table : ");
		t =sc.nextInt();
		
		for(int i=1; i<=10;i++)
		{
			//System.out.println(i*t);
			int o=i*t;
			System.out.println(t+"*"+i+"="+o);
		}
	}

}
