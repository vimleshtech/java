package session;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class test2 {

	public static void main(String[] args) throws IOException {

		BufferedReader br =
				new BufferedReader(new InputStreamReader(System.in));
		
		String name;
		System.out.println("enter string :");
		name = br.readLine();
		
			System.out.println("you have entered : "+name);
			
		
		

	}

}
