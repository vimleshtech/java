package inheritenceEx;

public class calc {

	int out;
	
	void add(int a, int b)
	{
		System.out.println("sum of two integer no. :"+a+b);
	}
	void sub(int a, int b)
	{
		System.out.println(a+b);
	}
}
