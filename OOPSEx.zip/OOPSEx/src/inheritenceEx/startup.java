package inheritenceEx;

public class startup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		///extendedcalc o =new extendedcalc();
		
		digitalcalc o = new digitalcalc();
		o.add(11, 22); // integer
		o.sub(33, 2);
		o.mul(22,3);
		o.add(2222.333,33.3); //double 
		
		
		
	}

}
