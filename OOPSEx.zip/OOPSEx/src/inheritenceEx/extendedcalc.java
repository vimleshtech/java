package inheritenceEx;

public class extendedcalc extends calc {

	void div(int a, int b)
	{
		System.out.println(a/b);
	}
	void mul(int a, int b)
	{
		System.out.println(a*b);
	}
	
}
