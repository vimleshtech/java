package inheritenceEx;

public class digitalcalc extends extendedcalc {

	void add(double a, double b)
	{
		System.out.println("sum of two double no. : "+a+b);
	}
}
