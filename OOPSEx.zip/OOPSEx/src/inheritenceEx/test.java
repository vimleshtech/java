package inheritenceEx;

public class test extends calc {

	int out;
	
	void hello()
	{
		out =10; //refer current class member
		this.out  =10;//refer current class member
		
		super.out=100;  //refer parent class member
		
		System.out.println("test class");
	}
}
