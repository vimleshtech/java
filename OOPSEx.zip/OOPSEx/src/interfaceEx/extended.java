package interfaceEx;

public class extended implements Bank,Security {

	@Override
	public void newAccount() {
		// TODO Auto-generated method stub
		
		System.out.println("new account");
	}

	@Override
	public void deposit(int amt) {
		// TODO Auto-generated method stub
		System.out.println("deposit");
		
	}

	@Override
	public int withdrawn(int accuntno) {
		// TODO Auto-generated method stub
		
		int a =111;
		return a;
	}

	@Override
	public void secureLogin() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void phoneLogin() {
		// TODO Auto-generated method stub
		
	}

}
