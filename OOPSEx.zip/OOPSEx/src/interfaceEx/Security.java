package interfaceEx;

public interface Security {

	void secureLogin();
	void phoneLogin();
	
}
