package interfaceEx;

public class caller {

	public static void main(String[] args) {

		extended e = new extended();
		e.newAccount();
		
		e.deposit(11122);
	int o = 	e.withdrawn(112);
	System.out.println(o);
		
		

	}

}
