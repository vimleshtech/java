package interfaceEx;

public interface Bank {

	void newAccount();
	void deposit(int amt);
	int withdrawn(int accuntno);
	
	
}
