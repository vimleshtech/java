package accessEx;

import java.util.Scanner;

public class startup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		calc o=new calc();
		//o.eid = 11;
		
		//o.calcSal();
		
		Scanner sc = new Scanner(System.in);
		int id,sa;
		id  =sc.nextInt();
		sa =sc.nextInt();
		o.sum(id,sa);
		
		
	}

}
