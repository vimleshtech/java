package accessEx;

public class calc {

	 private int eid,sal;
	
	 final int limit=1000;
	
	 private int calcSal(int sal)
	 {
		 return sal*12;
	 }
	
	void sum(int eid, int sal)
	{
		
		//this.limit =22;
		
		
		this.eid =eid;
		this.sal = this.calcSal(sal);
		
		
		if(this.sal>this.limit)
		{
			System.out.println("inta salary nahi ..");
		}
		
		
		
	}
	void disp()
	{
		System.out.println(eid);
		System.out.println(this.sal);
		
	}
}
