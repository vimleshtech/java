package abstractClassEx;

public class CurrentAccount extends BankAccount {

	@Override
	public void Account() {
		// TODO Auto-generated method stub
		
		System.out.println("min balance 25000 is required");
	}

}
