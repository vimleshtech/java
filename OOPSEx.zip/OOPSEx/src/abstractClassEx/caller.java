package abstractClassEx;

public class caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CurrentAccount c = new CurrentAccount();
		c.BankDetails();
		c.Account();
		
		SavingAccount s =new SavingAccount();
		s.Account();
		s.BankDetails();
		
		//instance cannot be created of abstract class
		//BankAccount b =new BankAccount();	
		
	}

}
