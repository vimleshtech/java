package abstractClassEx;

public class SavingAccount extends BankAccount {

	@Override
	public void Account() {
		
		System.out.println("min balance 10000 is required");	
	}

}
