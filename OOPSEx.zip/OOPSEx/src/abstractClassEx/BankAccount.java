package abstractClassEx;

public  abstract class BankAccount {
	
	public void BankDetails()
	{
		System.out.println("welcome to banking system");
	}
	
	public abstract void Account();
	
}
