package polymorphisamEx;

public class caller {

	public static void main(String[] args) {
		
		
		//parent class object
		calc c= new calc();
		c.welcome();
		c.add(11, 22.3);
		c.add(23.33, 333.2);
		c.add(11, 2,3);
		
		extendedcalc e = new extendedcalc();
		e.welcome();
		e.add(11.3, 33.33);
		e.mul(333, 33);
		
		//overriding 
		c=e;
		
		c.welcome();
		
		
	}

}
