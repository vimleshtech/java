package polymorphisamEx;

public class extendedcalc extends calc {

	void welcome()
	{
		System.out.println("welcome to calcualtion world class2..");
	}
	
	void mul(int a, int b)
	{
		System.out.println(a*b);
	}
	
	void add(int a, int b, double c, double d)
	{
		System.out.println(a+b+c+d);
	}
}
