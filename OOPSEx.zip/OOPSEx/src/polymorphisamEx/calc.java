package polymorphisamEx;

public class calc {

	void welcome()
	{
		System.out.println("welcome to calcualtion world..");
	}
	void add(int a, int b)
	{
		System.out.println("sum of two nu. "+(a+b));
	}
	void add(int a, int b,int c)
	{
		System.out.println("sum of three nu. "+(a+b+c));
	}
	
	void add(double a, double b)
	{
		System.out.println("sum of two double nu. "+(a+b));
	}
	
}
