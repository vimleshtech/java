package threadExample;

public class startup {

	public static void main(String[] args) throws InterruptedException {
		
		Thread t = new Thread();
		System.out.println(t);
		System.out.println(t.getName());
		System.out.println(t.getPriority());
		t.setName("Main Thread");
		System.out.println(t.getName());
		System.out.println(t);
		
		t = Thread.currentThread();
		System.out.println(t.isAlive());
		
		
		myThread oo = new myThread("New Process");
		
		
		for(int i=0; i<5;i++)
		{
			System.out.println("Thread -1 :"+i);
			Thread.sleep(2000);
		}

	}

}


class myThread implements Runnable{
	
	
	Thread t2 =null;
	
	myThread(String tname)
	{
		t2 = new Thread(this,tname);
		t2.start();
		
	}
	
	

	@Override
	public void run() {
		for(int i=0; i<5;i++)
		{
			System.out.println("Thread -2 :"+i);
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
}

