package jul3rd;

public abstract class absclass {
	
	public void test(int a, int b) {
		System.out.println("test");
	}
	public abstract void ab();
	

}
