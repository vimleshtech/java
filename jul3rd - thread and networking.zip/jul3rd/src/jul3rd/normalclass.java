package jul3rd;

public class normalclass extends absclass {

	@Override
	public void ab() {
		// TODO Auto-generated method stub
		
	}

}
