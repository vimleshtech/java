package example;

public class questionj5 {

	public static void main(String[] a)
	{
		
		Student s[]= new Student[3];//size of array
		for(int i=0;i<3;i++)
		{
			s[i] =new Student(); //memory init 
			s[i].input();			
		}
		
		
		//for(Student o:s)
		for(int i=0; i<3;i++)
			s[i].disp();
		
		
		
		//sorting 
		for(int i=0;i<s.length;i++)
		{
			for(int j=i+1;j<s.length;j++)
			{
				if(s[i].getRollNo()>s[j].getRollNo())
				{
					Student temp = s[i];
					s[i] = s[j];
					s[j] = temp;
				}
			}
		}
		
		//sorted data
		for(int i=0; i<3;i++)
			s[i].disp();
		
		//search 
		
	}
	
}
