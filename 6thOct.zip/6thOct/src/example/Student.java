package example;

import java.util.Scanner;

public class Student {

	int id;
	String name;
	int fee;
	
	void input()
	{
		Scanner sc =new Scanner(System.in);
		System.out.println("enter id :");
		id = sc.nextInt();
		
		System.out.println("enter name:");
		name = sc.next();

		System.out.println("enter fee :");
		fee = sc.nextInt();

	}
	
	int getRollNo()
	{
		return this.id;
	}
	void disp()
	{
		System.out.println(this.id);
		System.out.println(this.name);
		System.out.println(this.fee);
		
	}
}
