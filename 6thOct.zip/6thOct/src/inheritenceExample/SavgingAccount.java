package inheritenceExample;

import java.util.Scanner;

public class SavgingAccount extends BankAccount {

	
	String adno;
	String address;
	
	void welcome()
	{
		System.out.println("child class - SavingAccount");
	}
	
	void add(double a, double b)
	{
		System.out.println(a+b);
	}
	void add(double a, int b)
	{
		System.out.println(a+b);
	}
	
	public void newAccount()
	{
		super.newAccount();
		Scanner sc =new Scanner(System.in);		
		System.out.println("enter adhar no.:");
		adno= sc.next();

		System.out.println("enter address :");
		address= sc.next();

	}
	
	void show()
	{
		super.show();
		System.out.println(adno+"\t"+address);
		
	}
	

}
