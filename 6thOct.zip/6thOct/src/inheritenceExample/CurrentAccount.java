package inheritenceExample;

import java.util.Scanner;

public class CurrentAccount extends BankAccount {


	String gstno;
	String regproof;
	
	public void newAccount()
	{
		super.newAccount();
		Scanner sc =new Scanner(System.in);		
		System.out.println("enter adhar no.:");
		gstno= sc.next();

		System.out.println("enter address :");
		regproof= sc.next();

	}
	
	void show()
	{
		super.show();
		System.out.println(gstno+"\t"+regproof);
		
	}
	

}
