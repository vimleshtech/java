package inheritenceExample;

import java.util.Scanner;

public class BankAccount {

	int acctno;
	String acctname;
	double bal;

	void welcome()
	{
		System.out.println("parent class - BankAccount");
	}
	void add(int a, int b)
	{
		System.out.println(a+b);
	}
	void add(int a, int b, int c)
	{
		System.out.println(a+b+c);
	}
	protected	void newAccount()
	{
		Scanner sc =new Scanner(System.in);
		System.out.println("enter act id :");
		acctno = sc.nextInt();
		
		System.out.println("enter name:");
		acctname = sc.next();

		System.out.println("enter bal :");
		bal= sc.nextInt();

	}
	
	void show()
	{
		System.out.println(acctno+"\t"+acctname+"\t"+bal);
	}
	
}
