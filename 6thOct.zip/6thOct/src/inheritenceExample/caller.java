package inheritenceExample;

public class caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		SavgingAccount so =new SavgingAccount();
		so.newAccount();
		so.show();
		
		so.add(11, 22);
		so.add(33,333,22);
		so.add(111.22, 33); //double int
		//so.add(111.22, 33.333);//d d
		
		
		CurrentAccount co =new CurrentAccount();
		co.newAccount();
		co.show();
		*/
		
		//Example -1
		BankAccount ba =new BankAccount();
		ba.welcome();//parent
		
		SavgingAccount sa =new SavgingAccount();
		sa.welcome();
		
		//overriding
		ba = sa;
		ba.welcome();//child
		
		
		//Example -2
		//or
		BankAccount so =new SavgingAccount();
		so.welcome();
		
		//
		invokeToFunction(new SavgingAccount());
		invokeToFunction(new BankAccount());
		
	}
	
	static void invokeToFunction(BankAccount b)
	{
		b.welcome();
		b.newAccount();
		b.show();
		
		if( b instanceof SavgingAccount )
		{
			b.add(11, 2);
		}
		
	}

}
