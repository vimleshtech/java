package test;

public class startup 
{

	public static void main(String[] aa) 
	{
	
		//declartion of variable
		int a,b,c,d;
		
		//assign data over variable
		a =33;
		b =44;
		
		//operation / expression /logic
		c =a+b;
		
		//show result 
		System.out.println(c);
		
		
		//example:2
		int hs,es,cs,ms,total;
		
		hs =33;
		es =90;
		ms =90;
		cs  =56;
		
		total = hs+es+ms+cs;
		double avg = total/4;
		System.out.println(total);
		System.out.println(avg);
		
		//condtion : to print grade
		if(avg>60)
		{
			System.out.println("A");
		}
		else if(avg>50)
		{
			System.out.println("B");
		}
		else
		{
				System.out.println("C");
		}
			
		a=3;
		b=4;
		c=5;
		d=6;
			
		a =a*a*a;
		b=b*b*b;
		c=c*c*c;
		d=d*d*d;
		
		if(a+b+c == d)
		{
			System.out.println("condition matched");
		}
		else
		{
			System.out.println("condition not match");
		}
		
		
		int salary;
		
		salary=11000;
		
		if (salary >5000 && salary <=10000) {		
			
			double hra=salary*.10;
			double da=salary*.05;
			
			System.out.println("hra=="+hra);	
			System.out.println("da=="+da);	
			
	   }		
		else if (salary >10000 && salary <=15000) 
		{
			double hra=salary*.15;
			double da=salary*.08;
			
			System.out.println("hra=="+hra);	
			System.out.println("da=="+da);	
			
		}
	
int percentage;

percentage=60;
		
		if (percentage>=60)  {		
			
			
			
			System.out.println("First");	
			
			
	   }
		

		else if (percentage >=50 && percentage<=59)  {		
			
			
			
			System.out.println("Second");	
			
			
	   }
		
		
		else if (percentage >=40 && percentage<=49)  {		
			
			
			
			System.out.println("Third");	
			
			
	   }
		
		
		
		else  
		{
				
			System.out.println("fail");	
			
		}
			
			
			
	}
	
	
}
