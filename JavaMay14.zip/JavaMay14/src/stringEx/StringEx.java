package stringEx;

import java.util.Scanner;

public class StringEx {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter string data : ");
		String s = sc.nextLine(); //this is
		String ns;
		
		
		ns = s.toUpperCase();
		System.out.println(ns);

		ns = s.toLowerCase();
		System.out.println(ns);

		ns = s.replace("a","xy");
		System.out.println(ns);

		
		ns = s.substring(0, 3); // raman = ram 
		System.out.println(ns);
		

		ns = s.substring(3, 6); //  
		System.out.println(ns);

		int l;
		l = s.length();
		System.out.println(l);
		
		int ps;
		ps = s.indexOf("m");
		System.out.println(ps);
		
		
		char c;
		c = s.charAt(2);
		System.out.println(c);
		
		//raman kumar sinha= ["raman","kumar","sinha"]
		String aa[] = s.split(" "); 
		
		System.out.println(aa);
		System.out.println(aa[1]);
		
		
		if(s.contains("raman"))
		{
			System.out.println("matched");
		}
		else
		{
			System.out.println("not matched");
		}
		
		
		if(s.equalsIgnoreCase("raman kumar sinha"))
		{
			System.out.println("matched");
		}
		else
		{
			System.out.println("not matched");
		}
		
		if(s.equals("raman kumar sinha"))
		{
			System.out.println("matched");
		}
		else
		{
			System.out.println("not matched");
		}
		
		
		if(s.startsWith("raman"))
		{
			System.out.println("matched");
		}
		else
		{
			System.out.println("not matched");
		}
		
		
		if(s.endsWith("sinha"))
		{
			System.out.println("matched");
		}
		else
		{
			System.out.println("not matched");
		}
	}

}
