package loopExample;

import java.util.Scanner;

public class whileEx {

	public static void main(String[] args) {

		int i= 0; //init
		while(i<10) //condition
		{
			System.out.println(i);
			
			i++; // incrementer 
		}

		///////////////// print in serverse
		System.out.println("-----------------------");
		i =11;
		while(i>0)
		{
			System.out.println(i);
			i--;
		}
		

		///////////////// print all odd numbers between 3 to 100
		System.out.println("-----------------------");
		i =3;
		while(i<=100)
		{
			System.out.println(i);
			i+=2; //i = i+2
			
		}
		
		
		// print table of given no.
		System.out.println("-----------------------");
		int t;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number : ");
		t = sc.nextInt();
		
		i =1;
		while(i<=10)
		{
			System.out.println(i+"*"+t+"="+(i*t));
			i++;
			
		}
		
		
		
	}

}
