package loopExample;

public class nestedLoopEx {

	public static void main(String[] aa)
	{
		
		//r= 0, c = 0 1 2
		//r= 1, c = 0 1 2
		//r= 2, c = 0 1 2
		//r= 3, c = 0 1 2
		
		for(int r=0; r<4; r++)  //rows 
		{
			for(int c =0; c<3; c++) //cols
			{
				System.out.print(c+"\t");
			}
			System.out.println();			
		}
		
		
		for(int r=0; r<4; r++)  //rows 
		{
			for(int c =0; c<=r; c++) //cols
			{
				System.out.print("*");
			}
			System.out.println();			
		}
		
	}
}
