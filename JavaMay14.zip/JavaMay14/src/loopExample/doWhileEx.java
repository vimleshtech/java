package loopExample;

import java.util.Scanner;


public class doWhileEx {

	public static void main(String[] args) {

		int j =0;
		do
		{
			
			System.out.println(j);
			j++;
		}while(j<0);
		
		
		
		////
		Scanner sc = new Scanner(System.in);
		int ch=-1;
		int a=99,b=66;
		
		j =1;
		do
		{
			System.out.println("Enter your choice : 1. Press 1 for addition 2. press 2 for subs and 3. press 0 for exit ");
			ch = sc.nextInt();
			
			switch (ch) {
			case 0:
				//System.exit(0);
				j = 0;
				break;
			case 1:
				System.out.println(a+b);
				break;
			case 2:
				System.out.println(a-b);
				break;
			default:
				System.out.println("invalid choice...");
				break;
			}
			System.out.println(j);
			
		}while(j==1);
		
		System.out.println("end of code");

	}

}
