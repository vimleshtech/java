package loopExample;

import java.util.Scanner;

public class forExample {

	public static void main(String[] args) {



		for(int i=0; i<10;i++)
		
			System.out.println(i);
		
		///////////////// print in serverse
		System.out.println("-----------------------");
		for(int i=10;i>0;i--)
		{
			System.out.println(i);
		}
		

		///////////////// print all odd numbers between 3 to 100
		System.out.println("-----------------------");
		for(int i=3; i<=100;i=i+2)
		{
			System.out.println(i);
		}
		
		
		// print table of given no.
		System.out.println("-----------------------");
		int t;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number : ");
		t = sc.nextInt();
		
		for(int i=1; i<=10;i++)
			System.out.println(i*t);
		
	}

}
