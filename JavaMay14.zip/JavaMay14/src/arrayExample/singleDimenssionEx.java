package arrayExample;

import java.util.Scanner;

public class singleDimenssionEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n[]= {333,4,5,45,34};
		//array index will start at 0 position 
		//last index of array will be size of array  -1
		
		//access 2nd element of array
		System.out.println(n[1]);

		//access / print all elements
		int s=0;
		for(int d: n) //foreach loop / advance loop
		{
			s += d;
			System.out.println(d);
		}
		System.out.println("sum of all numbers : "+s);
		
		
		//2nd example
		String names[] = new String[3];
		names[0] ="raman";
		names[1] ="jatin";
		names[2] ="chahat";
		
		
		//tabular or 2 dimensssion
		
		String ss[][] = {{"Nitin","24","male"},{"Raman","28","male"}};
		
		for(String row[]: ss) //table to row (one d)
		{
			for(String cc: row)
			{
				System.out.print(cc);
			}
			System.out.println();
			
		}
		
		
		/// take data from user and store on array index
		int size=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter size of array:");
		size = sc.nextInt();
		
		int nn[] = new int[size];
		
		for(int i=0; i<size; i++)
		{
			System.out.println("enter data for array :");
			nn[i] = sc.nextInt();
		}
		
		for(int dd:nn)
		{
			System.out.println(dd);
		}
		
	}

}
