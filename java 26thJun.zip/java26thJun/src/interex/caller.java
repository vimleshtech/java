package interex;

public class caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		first f = new extendedclass();
		f.add(11, 2);
		f.sub(22,3);
		
		two t   = new extendedclass();
		t.div(33, 3);
		
	}

}
