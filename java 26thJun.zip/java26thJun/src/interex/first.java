package interex;

public interface first {

	void add(int a,int b);
	void sub(int a,int b);
	
	
}
