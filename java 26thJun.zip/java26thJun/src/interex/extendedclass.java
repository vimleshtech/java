package interex;

public class extendedclass implements first,two {

	@Override
	public void div(int a, int b) {
		// TODO Auto-generated method stub
		
		int c = a/b;
		System.out.println(c);
	}

	@Override
	public void add(int a, int b) {
		// TODO Auto-generated method stub

		int c = a+b;
		System.out.println(c);
		
	}

	@Override
	public void sub(int a, int b) {
		// TODO Auto-generated method stub

		int c = a-b;
		System.out.println(c);
		
	}

}
