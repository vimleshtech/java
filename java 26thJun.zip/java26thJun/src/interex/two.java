package interex;

public interface two {

	void div(int a, int b);
	
}
