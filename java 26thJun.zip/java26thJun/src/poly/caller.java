package poly;

public class caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		dcalc d = new dcalc();
		
		//overloading 
		d.add(111, 2.3);
		d.add(111, 2);
		d.add(111, 11);
		d.add(111.33, 2.3);
		d.add(111, 2,3);
		
		int aa[] = {111,2,2,3,4,4};
		d.add(aa);
		
		
		//overriding 
		calc c = new dcalc();
		c.welcome();
		
		//or
		calc co = new calc();
		co.welcome(); //parent class
		dcalc dco = new dcalc();
		dco.welcome(); //child class
		
		
		co = dco; //overwrite
		co.welcome(); //child class 
		
		
		
		
	}

}
