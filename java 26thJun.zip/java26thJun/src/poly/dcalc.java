package poly;

public class dcalc extends calc {

	public void add(double a, double b)
	{
		double c =a+b;
		System.out.println("sum of two decimal nu. :"+c);
	}
	public void add(double a, int b)
	{
		double c =a+b;
		System.out.println("sum of two decimal + int nu. :"+c);
	}
	
	public void add(int[] a)
	{
		
		int s=0;
		for(int x : a)
			s+= x;
		
		System.out.println("sum of all numbers : "+s);
	}
	
	
	public void welcome()
	{
		System.out.println("this class contains following functions  \n 1. add(double,double) 2. add(double, int) 2. add(int[])");
		
	}
	
}
