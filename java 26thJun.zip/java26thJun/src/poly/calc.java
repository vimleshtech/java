package poly;

public class calc {

	public void welcome()
	{
		System.out.println("this class contains following functions  \n 1. add(int,int) 2. add(int , int , int)");
		
	}
	public void add(int a,int b)
	{
		int c =a+b;
		System.out.println("sum of two nu. :"+c);
	}
	public void add(int a,int b, int c)
	{
		c =a+b+c;
		System.out.println("sum of three nu. :"+c);
	}
}
