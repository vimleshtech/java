package absExample;

public  abstract class absclass {

	public abstract void add(int a, int b);
	public abstract void mul(int a, int b);
	public abstract void div(int a, int b);
	public  void sub(int a, int b)
	{
		int c =a-b;
		System.out.println(c);
	}
	
}
