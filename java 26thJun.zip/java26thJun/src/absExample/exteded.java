package absExample;

public class exteded extends absclass {

	
	@Override //here @Overrid is annotation 
	public void add(int a, int b) {
		// TODO Auto-generated method stub
		
		int c=a+b;
		System.out.println(c);
	}

	@Override
	public void mul(int a, int b) {
		// TODO Auto-generated method stub

		int c=a*b;
		System.out.println(c);
		
	}

	@Override
	public void div(int a, int b) {
		// TODO Auto-generated method stub

		int c=a/b;
		System.out.println(c);
	}

}
