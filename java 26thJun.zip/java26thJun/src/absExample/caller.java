package absExample;

public class caller {

	public static void main(String[] aa)
	{
		absclass ab = new exteded();
		ab.add(11, 22);
		ab.mul(11, 22);
		ab.div(11, 22);
		ab.sub(11, 22);
		
		
	}
}
