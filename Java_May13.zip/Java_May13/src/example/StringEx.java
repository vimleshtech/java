package example;

//WAP to show count of space in sentence
//wap to show count of word in word
//wap to show count of particular word 
//wap to convert sentence to proper case 
// this is = This Is 


public class StringEx {

	public static void main(String[] args) {

		String name ="RAman sinha";
		String ns;
		
		ns = name.toUpperCase();
		System.out.println(ns);
		
		
		ns = name.toLowerCase();
		System.out.println(ns);
		

		ns = name.replace("a", "xy");
		System.out.println(ns);
		
		int l = name.length();
		System.out.println("coun of chars :"+l);
		
		
		System.out.println(name.replace(" ", "").length());
	
		//raman
		ns = name.substring(0, 3); // 0,1,2
		System.out.println(ns);
		
		//between 
		ns = name.substring(2, 5); // 2,3,4
		System.out.println(ns);
		
		//last 2 char
		ns = name.substring(name.length()-2, name.length()); // 0,1,2
		System.out.println(ns);
		
		//last one char
		ns = name.substring(name.length()-1, name.length()); // 0,1,2
		System.out.println(ns);
		
		
		
		int ps = name.indexOf("m");
		System.out.println(ps);
		ns = name.substring(ps,ps+3);
		
	
		char c = name.charAt(2);
		
		//name = raman kumar sinha = ["raman","kumar","sinha"]
		
		String data[] = name.split(" ");
		
		System.out.println(data[1]);
		
		if(name.equals("raman sinha"))
		{
			System.out.println("data matched");
		}
		else
		{
			System.out.println("not matched");	
		}
		
		if(name.equalsIgnoreCase("raman sinha"))
		{
			System.out.println("data matched");
		}
		else
		{
			System.out.println("not matched");	
		}
		
		if(name.contains("ma"))
		{
			
		}
		else
		{
			
		}
		
		
		if(name.startsWith("R"))
		{
			
		}
		else
		{
			
		}
		if(name.endsWith("@gmail.com") && name.startsWith("r"))
		{
			
		}
	}

}
