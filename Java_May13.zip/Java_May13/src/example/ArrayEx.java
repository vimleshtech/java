package example;

public class ArrayEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//single dimenssion array 
		
		int n[] = {11,2,33233,22}; //single dimenssion array
		//or
		int a[] = new int[3]; //  // single d array 
		a[0] =11;
		a[1] =1122;
		a[2] =1133;

		String name[] = new String[10];
		name[0] = "shjsg";
		
		//print 2nd element from array
		System.out.println(a[1]);
		
		//2 d array 
		int nn[][] = {{1,2,3},{34,33,4}};  // 2 * 3
		//or 
		int aa[][] = new int[2][3]; //no of is 2 and col is 3 
		aa[0][0] =1;
		aa[0][1] =2;
		aa[0][2] =1;


		aa[1][0] =100;
		aa[1][1] =1;
		aa[1][2] =1;
		
		//access the element (2 row , and 1 col)
		System.out.println(aa[1][0]);
	}

}
