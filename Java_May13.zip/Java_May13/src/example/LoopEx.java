package example;

public class LoopEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i=0; //init / start
		while(i<10) //condition 
		{
			System.out.println(i);
			i++; //increment 
		}
		
		//print in reverse order 
		i =10;
		while(i>0)
		{
			System.out.println(i);
			i--;
		}
		//print all odd numbers between 1 to 10
		
		i =1;
		while(i<10) //condition 
		{
			System.out.println(i);
			i=i+2; 
		}
		
		
		//for 
		for(int j=0; j<10;j++)
		{
			System.out.println(j);
		}
		

		//do while : will execute at least once 
		i =0;
		do
		{
			System.out.println(i);
			i++;
		}while(i<10);
	
		
		//loop :
		int n[] = {11,22,3,3,3};
		int s=0;
		for(int dd:n) //forward only
		{
			s=s+dd;
			System.out.println(dd);
		}
		System.out.println(s);
	}

}
