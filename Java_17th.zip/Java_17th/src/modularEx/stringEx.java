package modularEx;

import java.util.Scanner;

public class stringEx {

	public static void main(String[] args) {
		
		Scanner sc =new Scanner(System.in);
		String str, nstr;
		
		System.out.println("enter data: ");
		str = sc.nextLine();
		
		
		//to upper
		nstr = str.toUpperCase();
		System.out.println(nstr);
		
		//to lower
		nstr = str.toLowerCase();
		System.out.println(nstr);
				
		//replace
		nstr = str.replace("a", "bcd");
		System.out.println(nstr);
				
		//substring , cut string by given index
		nstr = str.substring(0, 3); //0 ,1 , 2
		System.out.println(nstr);
		
		nstr = str.substring(3, 6); //3,4,5
		System.out.println(nstr);
		
		//lenght
		int l = str.length(); //get count of chars including space
		System.out.println(l);
		
		
		//position , find char position 
		int ps;
		ps = str.indexOf("j");
		System.out.println(ps);

		//char at , get char by given index
		char c;
		c = str.charAt(1); 
		System.out.println(c);

		//split : break sentence in list/array by given seperator
		String ar[] = str.split(" ");//raman sinha =["raman","sinha"]
		System.out.println(ar[0]); //1st word
		System.out.println(ar[1]); //2nd word
		
		
		//conditional
		if(str.equals("raman")) //exact match
		{
			System.out.println("raman matched");
		}
		else
		{
			System.out.println("raman not matched");
		}
		
		//
		if(str.equalsIgnoreCase("Raman SINHA"))
		{
			System.out.println("raman sinha (in-case sensetive) matched");
		}
		else
		{
			System.out.println("raman sinha (in-case sensetive) not matched");
		}
		
		//
		if(str.startsWith("r"))
		{
			System.out.println("start with r");
		}
		else
		{
			System.out.println("not start with r");
		}
		//
		if(str.endsWith("n"))
		{
			System.out.println("end with n");
		}
		else
		{
			System.out.println("not end with n");
		}
		
		//
		if(str.contains("a")) //a should be anywhere
		{
			System.out.println("a contains");
		}
		else
		{
			System.out.println("a is not present ");
		}
	}

}
