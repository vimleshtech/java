package modularEx;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class fileHandlerEx {

	public static void main(String[] args) throws IOException {

		writeToFile();
		readFile();

	}
	public static void readFile()
	{
		
		try
		{
		FileReader fr  =new FileReader("C:\\Users\\vkumar15\\Desktop\\backup\\out.txt");
		BufferedReader br  =new BufferedReader(fr);
		
		String line="";
		
		
		FileWriter fw  =new FileWriter("C:\\Users\\vkumar15\\Desktop\\backup\\out2.txt",true); //true  - append in file  
		BufferedWriter bw  =new BufferedWriter(fw);
		
		
		while(( line = br.readLine())!=null )
		{
			System.out.println(line);
			bw.write(line);
			bw.newLine();
		}
		br.close();
		fr.close();
		bw.close();
		fw.close();
		
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	public static void writeToFile() throws IOException
	{
		FileWriter fw  =new FileWriter("C:\\Users\\vkumar15\\Desktop\\backup\\out.txt",true); //true  - append in file  
		BufferedWriter bw  =new BufferedWriter(fw);
		
		Scanner sc =new Scanner(System.in);
		String d ="";
		System.out.println("enter data : ");
		d = sc.nextLine();
		
		bw.write(d);
		bw.newLine();
		
		bw.close();
		fw.close(); //save and close the instance of file 
		
	}
}



