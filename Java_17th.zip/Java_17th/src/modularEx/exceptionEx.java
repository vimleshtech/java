package modularEx;

import java.util.Scanner;


public class exceptionEx {

	public static void main(String[] args) {

		
		Scanner sc =new Scanner(System.in);
		int n=0,d=0,o;
		
		
		try
		{	

				System.out.println("enter data : ");
				n =sc.nextInt();
				
				System.out.println("enter divisor : ");
				d =sc.nextInt();
		
				//throw: raise the based on user condition
				if(d<0)
				{
					ArithmeticException ex = new ArithmeticException("divisor cannot be in negative");
					throw ex;
					
				}
				
				o = n/d;				
				System.out.println("div  = "+o);
				
		}
		catch (ArithmeticException e) 
		{
			System.out.println(e);
		}
		catch (Exception e) //here Exception is inbuilt class, and e is object  
		{
			System.out.println("technical error");			
		}
		finally //is optional block , which will execute always either error will occur or not 
		{
			System.out.println("end of try block");
		}
		
		///
		o =n+d;
		System.out.println("sum of two numbers : "+o);
		
		
		

	}

}
