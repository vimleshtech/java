package modularEx;

import java.util.Scanner;

public class functionEx {

	public static void main(String[] args) {
		
		welcome();
		welcome();
		
		int a;
		a =getNumber();
		System.out.println(a);
		
		a =getNumber();
		System.out.println(a);
		

		//call with argument
		add(111,22);
		add(333,22);
		
		a = sub(111, 222);
		System.out.println(a);
		
	}
	
	//no argument no return
	public static void welcome()
	{
		System.out.println("welcome to function world..");
	}
	//no argument with return
	public static int getNumber()
	{
		int n;
		Scanner sc =new Scanner(System.in);
		System.out.println("enter data : ");
		n = sc.nextInt();
		
		return n;
	}
	
	//argument with no return
	public static void add(int a, int b)
	{
		int c =a+b;
		System.out.println("sum of two numbers : "+c);
	}
	//argument with return
	public static int sub(int a, int b)
	{
		int c =a-b;
		return c;
		
	}

}
