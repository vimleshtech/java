package practice;

import java.util.HashMap;
import java.util.Scanner;

public class hashMap 
{
	public static void main(String[] args) 
	{

		HashMap map =new HashMap();
		map.put("a", "apple"); //a (key/index) : apple/value
		map.put("t","tata");
		map.put("d","delta");
		
		Scanner sc =new Scanner(System.in);
		System.out.println("enter key to search :");
		String k = sc.next();
				
		System.out.println(map.get(k));		
		
	}
}
