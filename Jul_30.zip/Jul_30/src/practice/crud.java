package practice;

import java.util.Scanner;

public class crud {

	public static void main(String[] args) {

		Scanner sc =new Scanner(System.in);
		int ch,data,i=0;
		
		int arr[] =new int[5];
		
		//this is .next() = this
		//this is .nextLine() = this is
		
		while(true)
		{
			System.out.println("press 1 for add 2 for update 3 for show  4 for max value  5 for exit");
			ch = sc.nextInt();
			
			if(ch==1)
			{
				System.out.println("enter data to add: ");
				data = sc.nextInt();
				arr[i] =data;
				i++;
				
			}
			else if(ch==2)
			{
				System.out.println("enter index : ");
				int ind =sc.nextInt();
				System.out.println("enter new value: ");
				data = sc.nextInt();
				arr[ind] = data;
				
			}
			else if(ch==3)
			{
				for(int d=0;d<i;i++)
				System.out.println(arr[i]);
			}
			else if(ch==4)
			{
				int max=0;
				for(int d:arr)
				{
					if(max<d)
						max =d;
				}
				System.out.println("max value is: "+max);
			}
			else if(ch==5)
			{
					break;
			}
			else
			{
				System.out.println("Invalid choice");
			}
		}
		
		

	}

}
