package practice;

import java.util.ArrayList;
import java.util.List;

import javax.sound.midi.Soundbank;

public class listEx {

	public static void main(String[] args) {
		
		List l =new ArrayList();
		l.add(11);
		l.add("shsgs");
		
		System.out.println(l.size());
		l.remove(0);
		System.out.println(l.size());
		
		
		

		
	}

}
