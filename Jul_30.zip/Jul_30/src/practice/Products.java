package practice;

import java.util.HashMap;
import java.util.Scanner;

class prod
{
	int pid;
	String pname;
	
	prod(int p, String pname)
	{
		pid  = p;
		this.pname = pname;
	}
	
}

public class Products 
{
	public static void main(String[] args) 
	{		
		HashMap<Integer, prod>  p = new HashMap();
		
		Scanner sc =new Scanner(System.in);
		int id;
		String name;
		
		for(int i =0; i<5;i++)
		{
			System.out.println("enter id : ");
			id = sc.nextInt();
			System.out.println("enter name :");
			name = sc.next();
			
			p.put(id, new prod(id,name));
			
		}
		

		System.out.println("enter key to search :");
		id = sc.nextInt();
		
		System.out.println(p.get(id).pid +"\t"+p.get(id).pname);

		
	}

}
