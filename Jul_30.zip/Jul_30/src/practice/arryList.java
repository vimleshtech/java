package practice;

import java.util.ArrayList;

public class arryList {

	public static void main(String[] args) {
		
		//here ArrayList is inbuilt class which can hold any types of data 
		ArrayList al =new ArrayList();
		al.add(111);		//add() is function 
		al.add("raman");
		al.add("jatin");
		al.add("divya");
		al.add(true);
		al.add(1000);
		
		System.out.println("count of element : "+al.size());
		
		//access by index
		System.out.println(al.get(1)); //raman
		
		//remove element
		al.remove(2);
		System.out.println(al.size());
		
		//read all elements
		for(int i=0; i<al.size();i++)
			System.out.println(al.get(i));
		
		

	}

}
