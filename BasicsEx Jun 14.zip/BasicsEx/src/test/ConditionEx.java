package test;

import java.util.Scanner;

public class ConditionEx {

	public static void main(String[] args) {
	
		int n,a,b;
		Scanner sc =new Scanner(System.in);
		System.out.println("enter data  n: ");
		n = sc.nextInt();
		
		System.out.println("enter data a : ");
		a = sc.nextInt();
		
		System.out.println("enter data  b : ");
		b = sc.nextInt();
		
		
		//if condition 
		if(n%2 == 0)
		{
			System.out.println("even no");
		}
		
		//if else 
		if(n%2 == 0)
		{
			System.out.println("even no");
		}
		else 
		{
			System.out.println("odd no");
		}
		
		//if else if 
		if (a>b && a>n)
		{
			System.out.println("a is gt");
		}
		else if(b>a && b>n)
		{
			System.out.println(" b is gt");
		}
		else
		{
			System.out.println("n is gt");
		}
		
		//nested 
		if(a>b)
		{
			if(a>n)
			{
				System.out.println("a is gt");
			}
			else
			{
				System.out.println("n is gt");
				
			}
		}
		else
		{
			if(b>n)
			{
				System.out.println("b is gt");
			}
			else
			{
				System.out.println("n is gt");
				
			}
		}

	}

}
