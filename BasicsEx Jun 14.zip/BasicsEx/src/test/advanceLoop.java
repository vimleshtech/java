package test;

import java.util.Scanner;

public class advanceLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		int s;
		
		System.out.println("enter size of array ");
		s = sc.nextInt();
		
		int a[] = new int[s];
		
		for(int i=0;i<s; i++)
		{
			System.out.println("enter data for array ");		
			a[i] = sc.nextInt();
				
		}
		
		for(int x: a)
		{
			System.out.println(x);	
		}
	}

}
