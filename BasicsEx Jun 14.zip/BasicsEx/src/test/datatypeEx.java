package test;

public class datatypeEx {

	public static void main(String[] args) {

		//declaration of variable
		byte b =1;  //1 byte
		short s =333;   //2 byte
		int i =444;  // 4 byte
		long l =33333443; //8 byte
		
		System.out.println(b);
		System.out.println(s);
		System.out.println(i);
		System.out.println(l);
		
		//type casting : convert one data type to another
		
		//i. implicit: auto conversion (small to large type)
		l =i; 
		System.out.println(l);
		
		//ii. explicit : 
		i =(int)l;
		System.out.println(i);
		
		
		///
		char c='0';
		System.out.println(c);
		int n = c;
		System.out.println(n); //print ascii value 
		
		//bolean 
		boolean bo=true;
		System.out.println(bo);
		
		
		//float 
		float f =2333.333f; //4 byte
		System.out.println(f);
		
		//double 
		double d =433333.222333;  //8 byte
		System.out.println(d);

		//String 
		String ss ="skhsj shgf1h1222";
		System.out.println(ss);
		
		
	}

}
