package test;

public class whileEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i=1; //init
		while(i<10) // condition 
		{
			System.out.println(i);
			i++; //increment 
		}
		
		//reverse 
		i  =10;
		while(i>0)
		{
			System.out.println(i);
			i--;
		}
		
		//print all odd numbers between 1 to 100
		i =1;
		while(i<=100)
		{
			System.out.println(i);
			i+=2;
		}
		
	}

}
