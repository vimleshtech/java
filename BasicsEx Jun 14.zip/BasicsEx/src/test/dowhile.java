package test;

public class dowhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//do while : will execute at least once
		int i=1;
		
		do {
			
			System.out.println(i);
			i++;
			
		}while(i<0);
		
				
	}

}
