package test;

import java.util.Scanner;

public class switchCase {

	public static void main(String[] args) {

		
		Scanner sc = new Scanner(System.in);
		int day;
		System.out.println("enter day no. ");
		day = sc.nextInt();
		
		switch (day) {
		
		case 1:
			System.out.println("monday");
			
			break;
		case 2:
			System.out.println("tuesday");
			break;	
		default:
			System.out.println("invalid input");
			break;
		}

	}

}
