package oops;

import java.util.Scanner;

public class employee 
{

		//data memeber 
		private int eid;
		String ename; //default access specifier 
		int sal;

		final int taxsab=111;
		
		//
	public	int a;
	public	static int b;
		
		
		public employee()
		{
			ename="Guest User"; 
		}
		
		//with argument
		public employee(String country)
		{
			if(country.equals("india"))
			{
				ename="Guest User";
			}
			else if(country.equals("us"))
			{
				ename ="New User";
			}
			else
			{
				ename ="Un Registered user";
			}
		}
		
		
		//copy constructor
		public  employee(employee d)
		{
			ename = d.ename;
		}
		//function/method
		public void newEmployee()
		{
			Scanner sc =new Scanner(System.in);
			
			System.out.println("etner eid : ");
			eid = sc.nextInt();
			
			System.out.println("etner name : ");
			ename = sc.next();
			
			System.out.println("etner sal: ");
			sal= sc.nextInt();
			
			if(sal>taxsab)
			{
				System.out.println("tax is applicable");
			}
			
		}
	
		public void showDetails()
		{
			System.out.println("*****Employee Details*****");
			System.out.print("Employee Id : "+eid+"\t");
			System.out.print("Employee Name : "+ename+"\t");
			System.out.println("Employee Sal : "+sal);
			ename ="Mr "+ename;
		}
}
