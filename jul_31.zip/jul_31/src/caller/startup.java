package caller;

import oops.employee;

public class startup {

	static {
		System.out.println("test");
	}
	public static void main(String[] args) {
	
		employee o =new employee();
		employee o2 =new employee();
		//here o is object of class employee
		//new is keyword which allocates memory
		//employee() is default constructor
		
		o.showDetails();
		
		//o.newEmployee();
		o2.newEmployee();
				
		
		//o2.showDetails();
		o.showDetails();

		//
		o.a =11;
		o2.a =33;
		o.b =33;
		o2.b =5444;
		
		employee.b =33;
		//employee.a =33;//cannot be access
		o.a =33;
		
		
		
		System.out.println(o.a); //11
		System.out.println(o2.a);//33
		System.out.println(o.b);//5444
		System.out.println(o2.b);//5444
		
		//
		employee e=new employee("us");
		e.showDetails();
		
		//
		employee ee =new employee(e);
		ee.showDetails();
		
	}

}

