package caller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class fileReaderEx {

	public static void main(String[] args) throws IOException 
	{

		FileReader fr = new FileReader("C:\\Users\\Tech Vision\\Desktop\\Java Session - 31st Jul.txt");
		BufferedReader br =new BufferedReader(fr);
		
		String data;
		int rc=0;
		int wc=0;
		
		while( (data = br.readLine())!=null )
		{
			System.out.println(data);
			String col[] = data.split(" ");
			wc = wc+col.length;
			rc++;
		}
		
		System.out.println("row count :"+rc);
		System.out.println("word count :"+wc);
		
		br.close();
		fr.close();

		
		//writer 
		FileWriter fw =new FileWriter("C:\\Users\\Tech Vision\\Desktop\\out.txt",true); //true : append
		BufferedWriter bw =new BufferedWriter(fw);
		
		Scanner sc =new Scanner(System.in);
		
		for(int i=0; i<5; i++)
		{
			System.out.println("enter data ");
			data = sc.nextLine();
			bw.newLine();
			bw.write(data);
			
		}
		
		
		bw.close();
		fw.close();
	}

}
