package inheritence;

public class extendedCalc extends calc {

	int a;
	
	void mul(int a, int b)
	{
		
		System.out.println(super.a); //ref of parent class
		System.out.println(this.a); //ref of current class object
		//note if a is not exit in current class, then this ref to super class
		
		
		
		System.out.println(a*b);
		
	}
	void div(int a, int b)
	{
		System.out.println(a/b);
		
	}
}
