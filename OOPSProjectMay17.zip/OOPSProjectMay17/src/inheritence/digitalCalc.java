package inheritence;

public class digitalCalc {

}
