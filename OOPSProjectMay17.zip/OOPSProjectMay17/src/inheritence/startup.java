package inheritence;

public class startup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		extendedCalc o =new extendedCalc();
		o.div(11, 2);
		o.sum(11, 2);
		o.mul(11, 2);
		o.sub(11, 2);
		
	}

}
