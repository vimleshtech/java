package constructorAndStatic;

import java.util.Scanner;

public class startup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		employee e =new employee();
		
		employee e1 =new employee("us");
		
		employee ee = new employee(e1);
		
		employee.id =11;
		//employee.newUser();
		
		System.out.println("test"); //call to static function without instance 
		Scanner sc = new Scanner(System.in); 
		sc.nextLine(); //call to non static or instance function 
		
		
	}

}
