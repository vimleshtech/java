package constructorAndStatic;

public class employee {

	static	int id;
	String name;

	final int reward = 200;
	
	employee()
	{
		System.out.println("welcome to ...constructor world...");
	}
	
	employee(String country)
	{
		if(country.equals("india"))
		{
			System.out.println("Guest User");
			name ="Guest User";
			
		}
		else if(country.equals("us"))
		{
			System.out.println("New User");
			name ="new user";
		}
		else
		{
			System.out.println("Other User");
			name ="other";
		}
	}
	
	employee(employee e)
	{
		name  = e.name;
	}
	
	void newUser(String name)
	{
		
		
		this.name = name;
		this.id =22;
		
	}
}
