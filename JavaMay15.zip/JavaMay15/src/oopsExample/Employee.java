package oopsExample;

import java.util.Scanner;

//class 
public class Employee {

	//data member / attribute / global variable
	private	int eid;
	String ename;
	int esal;
	
	//method/ function
	void newEmployee() //int id, String n, int s
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter eid : ");
		eid = sc.nextInt();
		System.out.println("enter name : ");
		ename= sc.next();
		System.out.println("enter salary : ");
		esal = sc.nextInt();
	}
	
	void showEmployeeDetails()
	{
		System.out.println("******Employee Details******");
		System.out.println("Employee Id :"+eid);
		System.out.println("Employee Name :"+ename);
		System.out.println("Employee Salary :"+esal);
		System.out.println("Employee Anual Salary :"+(esal*12));
		
	}
	
	
	
}
