package oopsExample;

public class caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//create object of class Employee
		Employee e = new Employee(); 
		Employee e2 = new Employee();
		//here Employee is class, e is an object of class, and new is keyword which allocates memory of class Employee type
		
		e.newEmployee(); //111, "Nitin", 33344
		e2.newEmployee(); //221, "Raman", 55434
		
		
		e2.showEmployeeDetails();
		e.showEmployeeDetails();
		
	}

}

