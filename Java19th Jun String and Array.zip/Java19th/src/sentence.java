import java.util.Scanner;
public class sentence {
public static void main(String[]args)
{
	Scanner sc= new Scanner(System.in);
 String s;
 String nstr;
 System.out.println("enter sentence");
 s= sc.nextLine();
 nstr=s.toUpperCase();
 System.out.println(nstr);
 int l;
	l = s.length();
	System.out.println(l);
	
	s = s.trim();
	l= s.length();
	System.out.println(l);
	
	if(s.contains("is"))
	{
		System.out.println("is exist");
	}
	else
	{
		System.out.println("is is not exist");
	}
}
}
