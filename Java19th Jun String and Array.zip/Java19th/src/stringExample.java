
public class stringExample 
{
	public static void main(String[] args) 
	{

		//here String is data type 
		//name is variable
		//"raman sinha" is data or value
		String name ="  raman Sinha  ";
		String nstr;
		
		System.out.println("your text :"+name);
		
		nstr = name.toUpperCase();
		System.out.println(nstr);
		
		nstr = name.toLowerCase();
		System.out.println(nstr);
		
		nstr = name.replace("a", "xy");
		System.out.println(nstr);
		
		nstr = name.substring(2,5); //from 2 to 4 
		System.out.println(nstr);
		
		int l;
		l = name.length();
		System.out.println(l);
		
		
		name = name.trim();
		l=name.length();
		System.out.println(l);
		

		int ps;
		ps = name.indexOf("m");
		System.out.println(ps);
		
		char c;
		c = name.charAt(2);
		System.out.println(c);
		
		//convert char to ascii fomart
		int a;
		a = c;
		System.out.println(a);
		
		String nn[] = name.split(" ");//["raman","sinha"]
		System.out.println(nn[1]); //sinha
		
		
		char cc[] = name.toCharArray();//['r','a','m','a'..]
		for(int i=0; i<cc.length;i++)
		{
			System.out.println(cc[i]);
		}
		
		////conditional function
		if(name.equals("Raman Sinha"))
		{
			System.out.println("matched ..");
		}
		else
		{
			System.out.println("not matched ..");
		}
		//
		if(name.equalsIgnoreCase("Raman Sinha"))
		{
			System.out.println("matched ..");
		}
		else
		{
			System.out.println("not matched ..");
		}
		
		//
		if(name.contains("ma"))
		{
			System.out.println("ma exist");
		}
		else
		{
			System.out.println("ma is not exist");
		}
		
		//
		if(name.startsWith("r"))
		{
			System.out.println("start with r");
		}
		else
		{
			System.out.println("not start with r");
		}
		//
		if(name.endsWith("n"))
		{
			System.out.println("end with n");
		}
		else
		{
			System.out.println("not end with n");
		}
		
		//concat 
		String fn,ln;
		fn ="raman";
		ln ="sinha";
		
		name =fn+ln;
		System.out.println(name);
		
		name = fn.concat(ln);
		System.out.println(name);
		
	}

}
