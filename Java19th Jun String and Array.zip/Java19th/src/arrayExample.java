import java.util.Scanner;

public class arrayExample {

	public static void main(String[] args) {

		int n[]= {333,4,4,5,33};
		//array index start at 0 position 
		
		System.out.println(n[1]); //access 2nd element
		
		//access all elements
		for(int i=0; i<n.length;i++)
		{
			System.out.println(n[i]);
		}
		
		//
		int dd[] = new int[3];
		dd[0] =222;
		dd[1] =222;
		dd[2] =222;
		
		//wap to get sum of all elements
		int sum=0;
		
		for(int i=0; i<dd.length;i++)
		{
			System.out.println(dd[i]);
			sum = sum+dd[i];
		}
		
		System.out.println("sum of all elements "+sum);

		
		
		////
		//here Scanenr is inbuilt class
		//sc  is an object/instance of class Scanner
		//new is keyword which allocates the memory
		//System.in  : direction 
		Scanner sc =new Scanner(System.in);
		int s;
		System.out.println("enter size of array :");
		s = sc.nextInt();
		
		
		int data[] = new int[s];
		for(int i=0; i<s; i++)
		{
			System.out.println("enter data for array :");
			data[i] = sc.nextInt();
		}
		
		//output
		for(int i=0; i<s; i++)
		{
			System.out.println(data[i]);
		}
	}

}
