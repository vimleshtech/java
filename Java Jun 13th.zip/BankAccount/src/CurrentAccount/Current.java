package CurrentAccount;

import java.util.Scanner;

public class Current {

	//data members
	int accountNum;
	String accountName;
	String regNum;
	int amout;
	
	
	//methods 
	public void newAccount()
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter account no. :");
		accountNum = sc.nextInt();
		
		System.out.println("enter account name :");
		accountName=sc.next();
		
		System.out.println("enter account reg. no :");
		regNum =sc.next();

		System.out.println("enter amount :");
		amout= sc.nextInt();
		
		
		if(amout<25000)
		{
			System.out.println("your account cannot be open..min amount should be INR 25000");
			accountName="";
			regNum="";
			amout=0;
			accountNum=0;
			
					
		}
	}
	public void showAccountDetails()
	{
			System.out.println("Account No:"+accountNum);
			System.out.println("Account Name:"+accountName);
			System.out.println("Account Reg. Num.:"+regNum);
			System.out.println("Account Balance:"+amout);
			
	}
	
	
	
	
}
