package Main;

import CurrentAccount.Current;
import SavingAccount.*;///* import all classes

public class startup {

	public static void main(String[] args) {
		
		//here Saving is class, so is an object
		//new is keyword to allocate memory
		//Saving() : invoke or call to constuctor
		
		Saving so = new Saving();
		Current co  = new Current();
		
		//call / invoke to function
		so.accountNum =110;
		
		so.newAccount();
		so.showAccountDetails();

		co.newAccount();
		co.showAccountDetails();
		
		
	}

}
