package SavingAccount;

import java.util.Scanner;

public class Saving {

	//data members
	public	int accountNum;
	String accountName;
	String panNum;
	int amout;
	
	
	//methods 
	public void newAccount()
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter account no. :");
		accountNum = sc.nextInt();
		
		System.out.println("enter account name :");
		accountName=sc.next();
		
		System.out.println("enter account pn. no :");
		panNum =sc.next();

		System.out.println("enter amount :");
		amout= sc.nextInt();
	}
	public void showAccountDetails()
	{
			System.out.println("Account No:"+accountNum);
			System.out.println("Account Name:"+accountName);
			System.out.println("Account Pan. Num.:"+panNum);
			System.out.println("Account Balance:"+amout);
			
	}
	
	
	
}
