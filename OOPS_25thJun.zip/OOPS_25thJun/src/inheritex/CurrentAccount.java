package inheritex;

public class CurrentAccount extends BankAccount {

	String gstno;
	String regtno;
	

	public void newAccount(int ano,String aname,String gst, String reg)
	{
		
		super.ano = ano;
		super.aname =aname;
		this.gstno = gst;
		this.regtno =reg;
		
	}
	public void show()
	{
		System.out.println("Account no :"+super.ano);
		System.out.println("Account name :"+super.aname);
		System.out.println("Account gst no :"+this.gstno);
		
	}
	
	
}

