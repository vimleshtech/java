package inheritex;

public class BankAccount {

	public int ano;
	String aname;
	String panno;
	int amout;
	
}
