package inheritex;

public class SavingAccount extends BankAccount {

	String adharno;
	String address;
	
	public void newAccount(int ano,String aname,String adharno, String address)
	{
		
		super.ano = ano;
		super.aname =aname;
		this.adharno   = adharno;
		this.address =address;
		
	}
	public void show()
	{
		System.out.println("Account no :"+super.ano);
		System.out.println("Account name :"+super.aname);
		System.out.println("Account adhar no :"+this.adharno);
		
	}
}
