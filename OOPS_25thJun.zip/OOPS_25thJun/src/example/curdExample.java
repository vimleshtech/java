package example;

import java.net.SocketTimeoutException;
import java.util.Scanner;

import inheritex.SavingAccount;

public class curdExample {

	public static void main(String[] args) {
		
		SavingAccount ac [] = new SavingAccount[5];
		Scanner sc = new Scanner(System.in);
		String name,ano,add;
		int acno;
		
		
		for(int i=0; i<5;i++)
		{
			ac[i] = new SavingAccount();
			
			System.out.println("enter ano :");
			acno = sc.nextInt();
			
			System.out.println("enter aname :");
			name= sc.next();
			
			System.out.println("enter adh. no:");
			ano = sc.next();
			
			System.out.println("enter address :");
			add = sc.next();
			
			
			ac[i].newAccount(acno, name, ano, add);
		}
				
		
		while(true)
		{
			
			int op;
			System.out.println("enter 1. for show , 2. for sort 3. for search 4.for exit");
			op = sc.nextInt();
			
			if(op==1)
			{
			
				for(int i=0; i<5;i++)
					ac[i].show();
					
			}
			else if(op==2)
			{
				for(int i=0; i<5;i++)
				{
					for(int j=i+1; j<5;j++)
					{
						if(ac[i].ano>ac[j].ano  )
						{
							SavingAccount temp =ac[i];
							ac[i] = ac[j];
							ac[j] = temp;
						}
						
					}	
				}
					
				
			}
			else if(op==3)
			{
				System.out.println("enter ac no. to search :");
				acno = sc.nextInt();
				
				for(int i=0; i<5;i++)
				{
					if(acno == ac[i].ano)
					{
						ac[i].show();
					}
				}
			}
			else if(op==4)
			{
				System.out.println("thank you..");
				break;
			}
			else
			{
				System.out.println("invalid choice");	
			}
		}

	}

}
