package example;

public class emp 
{

	static int a;
	int b;
	
}
