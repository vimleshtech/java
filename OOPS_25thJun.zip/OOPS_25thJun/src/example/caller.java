package example;

import inheritex.CurrentAccount;
import inheritex.SavingAccount;

public class caller {

	public static void main(String[] args) {


		/*
		emp o1 = new emp();
		emp o2 = new emp();
		
		o1.a =1;
		o1.b =1;
		

		o2.a =2;
		o2.b =2;
		
		System.out.println(o1.a);//2
		System.out.println(o2.a);//2
		
		System.out.println(o1.b);//1
		System.out.println(o2.b);//2
		*/
		emp.a =11;
		//emp.b =33;
		emp oo =new emp();
		oo.b =22;
		
		////
		SavingAccount so = new SavingAccount();
		CurrentAccount co = new CurrentAccount();
		
		so.newAccount(111, "Nitin Sinha", "ad0012", "tilak nagar");
		co.newAccount(200001, "Tech Vision Information Services", "GST002113","RG9934344");
		
		co.show();
		so.show();
	}

}
