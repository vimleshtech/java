package test;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.io.FileHandler;

public class loginExample {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		WebDriver driver =new FirefoxDriver();
		driver.get("http://erp.techvisionit.com/");
		
		//try with wrong user id and password 
		/*
		driver.findElement(By.id("txtUserName")).sendKeys("raman");
		driver.findElement(By.id("txtPassword")).sendKeys("abcd");
		driver.findElement(By.id("btnSubmit")).click();
	
		String msg = driver.findElement(By.id("lblmsg")).getText();
		
		System.out.println(msg);
		*/
	
		//try with correct user id and password
		driver.findElement(By.id("txtUserName")).sendKeys("chahat");
		driver.findElement(By.id("txtPassword")).sendKeys("chahat@765");
		driver.findElement(By.id("btnSubmit")).click();
			
		
		String url = driver.getCurrentUrl();
		System.out.println(url);
		
		//take screenshot 
		File src =	((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileHandler.copy(src, new File("C:\\Users\\Tech Vision\\Desktop\\compute\\out.png"));
		
		
		
		
	}

}
