package test;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.events.WebDriverEventListener;

public class hello {

	public static void main(String[] args) {
				
		WebDriver driver =new FirefoxDriver();
		driver.get("https://www.yahoo.com/");
		
		List<WebElement> aaa =	
			driver.findElements(By.tagName("a"));
	
		
		System.out.println(aaa.size());
		for(WebElement e : aaa)
		{
			System.out.println(e.getText());
		}
		
	
		
		
		

	}

}
