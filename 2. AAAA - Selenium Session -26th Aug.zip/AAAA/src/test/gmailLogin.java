package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class gmailLogin {

	public static void main(String[] args) throws InterruptedException {

		
		//waiting time
		/*There are following types:
		 * i. implicit
		 * ii. explicit 
		 */
		WebDriver driver = new FirefoxDriver();
		driver.get("https://www.google.com/");
		//exact match
		driver.findElement(By.linkText("Gmail")).click();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.linkText("SIGN IN")).click();
		
		driver.findElement(By.id("identifierId")).sendKeys("vimlesh073");
		driver.findElement(By.id("identifierNext")).click();
		
		//explicit
		Thread.sleep(5000);		

		driver.findElement(By.name("password")).sendKeys("EveVision@26");
		driver.findElement(By.id("passwordNext")).click();
		
		
	}

}
